# Importar Librerias de Mesa para la ejecucion del codigo
from mesa.model import Model
import numpy as np


from mesa import Agent, Model
from mesa.space import MultiGrid
from mesa.time import BaseScheduler


from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.UserParam import Slider, Checkbox


from pathfinding.core.diagonal_movement import DiagonalMovement
from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder


from mesa.datacollection import DataCollector
from mesa.visualization.modules import ChartModule


#Agente Mosaico
class Tile(Agent):
    CLEAN = 0
    DIRTY = 1
   
    def __init__(self, model: Model, pos):
        super().__init__(model.next_id(), model)
        self.condition = self.DIRTY
        self.pos = pos


#Agente Incinerador
class Incinerator(Agent):
    OFF = 0
    ON = 1
    OCUPPIED = 2
   
    def __init__(self, model: Model, pos):
        super().__init__(model.next_id(), model)
        self.condition = self.OFF
        self.pos = pos
        self.loaded = 0
       
    def step(self):
        print("INCINERATOR")
       
        print(self.condition)
       
        if (Bot not in self.model.grid.get_cell_list_contents([self.pos]) and self.loaded == 1):
            self.loaded = 0
        elif (self.condition == self.OCUPPIED):
            self.condition = self.ON
        else:
            self.condition = self.OFF
           
        print(self.condition)
       
#Agente Robot
class Bot(Agent):
    EMPTY = 0
    FULL = 1
    RETURNING = 2
   
    def __init__(self, model: Model, id, pos, dimi):
        super().__init__(model.next_id(), model)
        self.id = id
        self.pos = pos
        self.dimi = dimi
        self.check = self.pos
        self.matrix = self.model.matrix
       
        self.acum = 0
       
    def step(self):
        print("Robot: ", self.id)
       
        # print(np.matrix(self.matrix))
        mid = (self.dimi - 1)//2
        grid = Grid(matrix = self.matrix)
        self.pos = tuple(self.pos)
        (x, y) = self.pos
        start = grid.node(x, y)
       
        matrixE = np.ones((self.dimi, self.dimi), dtype=np.int32)
        # print(np.matrix(matrixE))
        gridE = Grid(matrix = matrixE)
        startE = gridE.node(x, y)
       
        inci = []
       
        for object in self.model.grid.get_neighbors((x, y), moore=True):
            if (type(object) == Incinerator):
                inci = object
       
        if (type(inci) == Incinerator and inci.condition == inci.OCUPPIED):
            print("Incinerator OCUPPIED")
           
        elif (type(inci) == Incinerator and inci.condition == inci.ON):
            print("Incinerator ON")
       
        elif (self.condition == self.EMPTY):
            new_pos = np.array([x + self.random.randrange(-1, 2, 1), y + self.random.randrange(-1,2,1)])
            while (self.model.grid.out_of_bounds(new_pos)) :
                new_pos = np.array([x + self.random.randrange(-1, 2, 1), y + self.random.randrange(-1,2,1)])
            self.model.grid.move_agent(self, new_pos)
            self.acum += 1
           
            for object in self.model.grid.get_cell_list_contents([self.pos]):
                if (type(object) == Tile and object.condition == object.DIRTY):
                    object.condition = object.CLEAN
                    self.condition = self.FULL
                    self.check = self.pos
                    self.pos = tuple(self.pos)
                    (x, y) = self.pos
                    # print(np.matrix(self.matrix))
                    # print("DESPUES")
                    self.matrix[y][x] = 1
                    # print(np.matrix(self.matrix))
                   
           
        elif (self.condition == self.FULL):
            # print(np.matrix(self.matrix))
            print("ESTOY EN: ", self.pos)
            end = grid.node(mid, mid)
            finder = AStarFinder(diagonal_movement=DiagonalMovement.never)
            path, runs = finder.find_path(start, end, grid)
           
            if path != []:
                print(path)
                self.model.grid.move_agent(self, path[1])
                print("LLEGUE A: ", self.pos)
                self.pos = tuple(self.pos)
                (x, y) = self.pos
                # print("EN MATRIZ: ", self.matrix[y][x])
                self.acum += 1
           
                for object in self.model.grid.get_cell_list_contents([self.pos]):
                    if (type(object) == Incinerator and object.condition == object.OFF):
                        self.condition = self.RETURNING
                        object.loaded = 1
                        object.condition = object.OCUPPIED
            else:
                print("BLOQUEADO")
                endE = gridE.node(mid, mid)                
                pathE, runsE = finder.find_path(startE, endE, gridE)
                print(pathE)
               
                (x, y) = pathE[0]
                for object in self.model.grid.get_cell_list_contents([pathE[0]]):
                    if (type(object) == Tile):
                        object.condition = object.DIRTY
                        self.condition = self.EMPTY
                        self.matrix[y][x] = 0
                       
                (x, y) = pathE[1]
                for object in self.model.grid.get_cell_list_contents([pathE[1]]):
                    if (type(object) == Tile and object.condition == object.DIRTY):
                        object.condition = object.CLEAN
                        self.condition = self.FULL
                        self.check = self.pos
                        self.matrix[y][x] = 1
                       
                self.model.grid.move_agent(self, pathE[1])
                print("LLEGUE A: ", self.pos)
                # (x, y) = self.pos
                # print("EN MATRIZ: ", self.matrix[y][x])
                self.acum += 1
       
        elif (self.condition == self.RETURNING):
            print("VOY DE VUELTA")
            (x1, y1) = self.check
            self.pos = tuple(self.pos)
            (x2, y2) = self.pos
            if ((x1, y1) == (x2, y2)):
                self.condition = self.EMPTY
            else:
                end = grid.node(x1, y1)
                finder = AStarFinder(diagonal_movement=DiagonalMovement.never)
                path, runs = finder.find_path(start, end, grid)
                if path != []:
                    self.model.grid.move_agent(self, path[1])
                    self.acum += 1
                else:
                    endE = gridE.node(x1, y1)
                    pathE, runsE = finder.find_path(startE, endE, gridE)
                           
                    (x, y) = pathE[1]
                    for object in self.model.grid.get_cell_list_contents([pathE[1]]):
                        if (type(object) == Tile and object.condition == object.DIRTY):
                            object.condition = object.CLEAN
                            self.condition = self.FULL
                            self.check = self.pos
                            self.matrix[y][x] = 1
                       
                    self.model.grid.move_agent(self, pathE[1])
                    self.acum += 1
                   
             
           
#Modelo Piso
class Floor(Model):
    def __init__(self, height=51, density=0.01):
        super().__init__()
        self.schedule = BaseScheduler(self)
        self.height = height
       
        if (height == False):
            height = 21
            mid = 10
            b0 = [0, 0]
            b1 = [0, 20]
            b2 = [20, 20]
            b3 = [20, 0]
            b4 = [0, 10]
            b5 = [10, 0]
        else:
            height = 51
            mid = 25
            b0 = [0, 0]
            b1 = [0, 50]
            b2 = [50, 50]
            b3 = [50, 0]
            b4 = [0, 25]
            b5 = [25, 0]
       
        self.grid = MultiGrid(height, height, torus=False)
        self.matrix = np.ones((height, height), dtype=np.int32)
       
        count = 0
        for i in np.random.choice(mid + 1, 6, replace=False):
            if count == 0:
                bot = Bot(self, 0, np.array(b0), height)
            elif count == 1:
                bot = Bot(self, 1, np.array(b1), height)
            elif count == 2:
                bot = Bot(self, 2, np.array(b2), height)
            elif count == 3:
                bot = Bot(self, 3, np.array(b3), height)
            elif count == 4:
                bot = Bot(self, 4, np.array(b4), height)
            elif count == 5:
                bot = Bot(self, 5, np.array(b5), height)
   
            count += 1
           
            bot.condition = Bot.EMPTY
               
            self.grid.place_agent(bot, bot.pos)
            self.schedule.add(bot)
       
        for _,(x,y) in self.grid.coord_iter():
            if x == mid and y == mid:
                obj = Incinerator(self, (x, y))
                obj.condition = Incinerator.OFF
            elif (x == b0[0] and y == b0[1]) or (x == b1[0] and y == b1[1]) or (x == b2[0] and y == b2[1]) or (x == b3[0] and y == b3[1]) or (x == b4[0] and y == b4[1]) or (x == b5[0] and y == b5[1]):
                obj = Tile(self, (x, y))
                obj.condition = Tile.CLEAN
            elif self.random.random() < density:
                obj = Tile(self, (x, y))
                obj.condition = Tile.DIRTY
                self.matrix[y][x] = 0
            else:
                obj = Tile(self, (x, y))
                obj.condition = Tile.CLEAN
            self.grid.place_agent(obj, (x,y))
            self.schedule.add(obj)
           
        # print(np.matrix(self.matrix))    
        self.datacollector = DataCollector({"Percent dirty": lambda m: self.count_type(m, Tile.DIRTY) / len(self.schedule.agents)})
     
    @staticmethod
    def count_type(model, condition):
        count = 0 # Contador
        for garbage in model.schedule.agents:
            if garbage.condition == condition:
                count += 1
        return count
               
    def step(self): # Continuar la ejecucion
        self.schedule.step()
        self.datacollector.collect(self)
       
        # Detener los steps
        if self.schedule.steps == 1500:
            print("FIN DE SIMULACIÓN")
            print("RESULTADOS:")
            print("Steps de simulación: ", self.schedule.steps)
            for i in [1, 2, 3, 4, 5, 6]:
                bot = [bot for bot in self.schedule.agents if bot.unique_id == i][0]
                print("Pasos de bot ", bot.id, ": ", bot.acum)
            self.running = False
        elif (self.count_type(self, Tile.DIRTY) == 0):
            print("FIN DE SIMULACIÓN")
            print("RESULTADOS:")
            print("Steps de simulación: ", self.schedule.steps)
            for i in [1, 2, 3, 4, 5, 6]:
                bot = [bot for bot in self.schedule.agents if bot.unique_id == i][0]
                print("Pasos de bot ", bot.id, ": ", bot.acum)
            self.running = False
           
#def agent_portrayal(agent):
#    if type(agent) == Tile:
#        if agent.condition == Tile.CLEAN:
#            portrayal = {"Shape": "rect", "Filled": "true", "Color": "Green", "w": 1, "h": 1, "Layer": 0}
#        elif agent.condition == Tile.DIRTY:
#            portrayal = {"Shape": "circle", "Filled": "true", "Color": "Gray", "r": 1, "Layer": 0}
#    elif type(agent) == Incinerator:
#        if agent.condition == Incinerator.OFF or agent.condition == Incinerator.OCUPPIED:
#            portrayal = {"Shape": "rect", "w": 1, "h": 1, "Filled": "true", "Color": "Black", "Layer": 0}
#        elif agent.condition == Incinerator.ON:
#            portrayal = {"Shape": "rect", "w": 1, "h": 1, "Filled": "true", "Color": "Red", "Layer": 0}
#    elif type(agent) == Bot:
#        portrayal = {"Shape": "rect", "w": 1, "h": 1, "Filled": "true", "Color": "Blue", "Layer": 1}
#    else:
#        portrayal = {}


#    return portrayal


#chart = ChartModule([{"Label": "Percent dirty", "Color": "Black"}], data_collector_name='datacollector')
   
#grid = CanvasGrid(agent_portrayal, 51, 51, 459, 459)
#server = ModularServer(Floor,
#                    [grid,chart],
#                    "Floor",
#                    {"density": Slider("Garbage Density", 0.25, 0.01, 1.0, 0.01),
#                    "height": Checkbox("Dimenciones", False),
#                    }
#                    )


#server.port = 8522
#server.launch()
