import flask
from flask.json import jsonify
import uuid
from recolectores import Floor,Bot,Tile


games = {}


app = flask.Flask(__name__)


@app.route("/games", methods=["POST"])
def create():
    global games
    id = str(uuid.uuid4())
    model = games[id] = Floor()


    agentes = []
   
    lista = []
    for bot in model.schedule.agents:
        if isinstance(bot,Bot):
            lista.append({"id": bot.unique_id, "x": int(bot.pos[0]), "z": int(bot.pos[1])})
    agentes.append(lista)
           
    lista = []
    for trash in model.schedule.agents:
        if isinstance(trash,Tile):
            if trash.condition == 1:
                lista.append({"id": trash.unique_id, "x": int(trash.pos[0]), "z": int(trash.pos[1])})
    agentes.append(lista)
           
    return jsonify({'Location': f"/games/{id}", "agents": agentes}), 201, {'Location': f"/games/{id}"}


@app.route("/games/<id>", methods=["GET"])
def queryState(id):
    global model
    model = games[id]
    model.step()
   
    agentes = []
   
    lista = []
    for bot in model.schedule.agents:
        if isinstance(bot,Bot):
            bot.pos = tuple(bot.pos)
            lista.append({"id": bot.unique_id, "x": int(bot.pos[0]), "z": int(bot.pos[1])})
    agentes.append(lista)
   
    lista = []
    for trash in model.schedule.agents:
        if isinstance(trash,Tile):
            if trash.condition == 1:
                lista.append({"id": trash.unique_id, "x": int(trash.pos[0]), "z": int(trash.pos[1])})
    agentes.append(lista)
           
    return jsonify(agentes)


app.run(host="0.0.0.0", port=5100)