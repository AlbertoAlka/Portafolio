#Autor: Ivan Olmos Pineda
#Curso: Multiagentes - Graficas Computacionales


import pygame
from pygame.locals import *


# Cargamos las bibliotecas de OpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from objloader import *
import math

viewport = (800,600)
hx = viewport[0]/2
hy = viewport[1]/2
srf = pygame.display.set_mode(viewport, OPENGL | DOUBLEBUF)

glLightfv(GL_LIGHT0, GL_POSITION,  (-40, 100, 100, 0.0))
glLightfv(GL_LIGHT0, GL_AMBIENT, (0.8, 0.8, 0.8, 1.0))
glLightfv(GL_LIGHT0, GL_DIFFUSE, (0.8, 0.8, 0.8, 1.0))
glEnable(GL_LIGHT0)
glEnable(GL_LIGHTING)
glEnable(GL_COLOR_MATERIAL)
glEnable(GL_DEPTH_TEST)
glShadeModel(GL_SMOOTH)           # most obj files expect to be smooth-shaded


class Basura:
   
    def __init__(self, x, z):
        #Se inicializa las coordenadas de los vertices del cubo
        self.vertexCoords = [  
                   1,1,1,   1,1,-1,   1,-1,-1,   1,-1,1,
                  -1,1,1,  -1,1,-1,  -1,-1,-1,  -1,-1,1  ]
        #Se inicializa los colores de los vertices del cubo
        self.vertexColors = [
                   1,1,1,   1,0,0,   1,1,0,   0,1,0,
                   0,0,1,   1,0,1,   0,0,0,   0,1,1  ]
        #Se inicializa el arreglo para la indexacion de los vertices
        self.elementArray = [
                  0,1,2,3, 0,3,7,4, 0,4,5,1,
                  6,2,1,5, 6,5,4,7, 6,7,3,2  ]


        self.Position = [x, 5.0, z]
        self.angulo_inc=1
        self.Direction=[0,0,0]
        self.colision = 0
       


    
    
    def update(self, new_x, new_z):
        self.Position[0] = new_x
        self.Position[2] = new_z


    def draw(self,texture_id):
        if self.colision != 1:

            glPushMatrix()
                
            glTranslatef(self.Position[0], self.Position[1], self.Position[2])
            glScalef(12.0,12.0,12.0)
            #glRotatef(self.angulo_demo, 0, 1, 0)
            #glTranslatef(0.0,0.75,-0.15) 
            glTranslatef(0.0,1.0,-0.15) 

            
            # Front face (turquoise)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[10])
            glColor3f(1.0, 1.0, 1.0)
            glBegin(GL_QUADS)

            # Coordenadas de textura invertidas verticalmente
            glTexCoord2f(0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)

            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)

            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, 0.5)

            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, 0.5)

            glEnd()
            



            # Back face (green)
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 1.0)
            #glColor3f(0.0, 1.0, 0.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)

            # Top face (yellow)
            
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[11])
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 0.0)
            glColor3f(1.0, 1.0, 1.0)
            glVertex3f(-0.5, 0.5, 0.5)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(0.5, 0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)
            
            

            # Bottom face (magenta)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[10])
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 1.0)
            #glColor3f(1.0, 0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glEnd()

            # Left face (red)
            glBegin(GL_QUADS)
            #glColor3f(1.0, 0.0, 0.0)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, 0.5)
            glEnd()

            # Right face (blue)
            glBegin(GL_QUADS)
            #glColor3f(0.0, 0.0, 1.0)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(0.5, 0.5, 0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)
            
            glPopMatrix()
            #glDisable(GL_TEXTURE_2D)
#Autor: Ivan Olmos Pineda
#Curso: Multiagentes - Graficas Computacionales


import pygame
from pygame.locals import *


# Cargamos las bibliotecas de OpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from objloader import *
import math

viewport = (800,600)
hx = viewport[0]/2
hy = viewport[1]/2
srf = pygame.display.set_mode(viewport, OPENGL | DOUBLEBUF)

glLightfv(GL_LIGHT0, GL_POSITION,  (-40, 100, 100, 0.0))
glLightfv(GL_LIGHT0, GL_AMBIENT, (0.8, 0.8, 0.8, 1.0))
glLightfv(GL_LIGHT0, GL_DIFFUSE, (0.8, 0.8, 0.8, 1.0))
glEnable(GL_LIGHT0)
glEnable(GL_LIGHTING)
glEnable(GL_COLOR_MATERIAL)
glEnable(GL_DEPTH_TEST)
glShadeModel(GL_SMOOTH)           # most obj files expect to be smooth-shaded

# LOAD OBJECT AFTER PYGAME INIT
#obj = OBJ(sys.argv[1], swapyz=True)
obj = OBJ("car.obj", swapyz=True)
obj.generate()

class Basura:
   
    def __init__(self, x, z):
        #Se inicializa las coordenadas de los vertices del cubo
        self.vertexCoords = [  
                   1,1,1,   1,1,-1,   1,-1,-1,   1,-1,1,
                  -1,1,1,  -1,1,-1,  -1,-1,-1,  -1,-1,1  ]
        #Se inicializa los colores de los vertices del cubo
        self.vertexColors = [
                   1,1,1,   1,0,0,   1,1,0,   0,1,0,
                   0,0,1,   1,0,1,   0,0,0,   0,1,1  ]
        #Se inicializa el arreglo para la indexacion de los vertices
        self.elementArray = [
                  0,1,2,3, 0,3,7,4, 0,4,5,1,
                  6,2,1,5, 6,5,4,7, 6,7,3,2  ]


        self.Position = [x, 5.0, z]
        self.angulo_inc=1
        self.Direction=[0,0,0]
        self.colision = 0
       


    
    
    def update(self, new_x, new_z):
        self.Position[0] = new_x
        self.Position[2] = new_z


    def draw(self,texture_id):
        if self.colision != 1:

            glPushMatrix()
                
            glTranslatef(self.Position[0], self.Position[1], self.Position[2])
            glScalef(12.0,12.0,12.0)
            #glRotatef(self.angulo_demo, 0, 1, 0)
            #glTranslatef(0.0,0.75,-0.15) 
            glTranslatef(0.0,1.0,-0.15) 

            
            # Front face (turquoise)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[10])
            glColor3f(1.0, 1.0, 1.0)
            glBegin(GL_QUADS)

            # Coordenadas de textura invertidas verticalmente
            glTexCoord2f(0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)

            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)

            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, 0.5)

            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, 0.5)

            glEnd()
            



            # Back face (green)
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 1.0)
            #glColor3f(0.0, 1.0, 0.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)

            # Top face (yellow)
            
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[11])
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 0.0)
            glColor3f(1.0, 1.0, 1.0)
            glVertex3f(-0.5, 0.5, 0.5)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(0.5, 0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)
            
            

            # Bottom face (magenta)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[10])
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 1.0)
            #glColor3f(1.0, 0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glEnd()

            # Left face (red)
            glBegin(GL_QUADS)
            #glColor3f(1.0, 0.0, 0.0)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, 0.5)
            glEnd()

            # Right face (blue)
            glBegin(GL_QUADS)
            #glColor3f(0.0, 0.0, 1.0)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(0.5, 0.5, 0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)
            
            glPopMatrix()
            #glDisable(GL_TEXTURE_2D)
