import pygame
from pygame.locals import *


# Cargamos las bibliotecas de OpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
import math

# Se carga el archivo de la clase Cubo
from Robot import Robot
from Basura import Basura


import requests
URL_BASE = "http://10.50.94.201:5100"
r = requests.post(URL_BASE+ "/games", allow_redirects=False)
print(r)

# LOCATION = r.headers["Location"]
informacion = r.json()
print(informacion)
LOCATION = informacion["Location"]
lista = informacion["agents"]


#lista = r.json()



RADIUS = 670.82  # Valor del radio, es este porque estamos usando el radio donde empeiza el observador, que es 300 en cada plano, por lo que la hipotenusa es esa


screen_width = 600
screen_height = 600

#vc para el obser.
FOVY=70.0
ZNEAR=0.01
ZFAR=900.0
#Variables para definir la posicion del observador
#gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z)
EYE_X=600.0
EYE_Y=300.0
EYE_Z=600.0
CENTER_X=0
CENTER_Y=0
CENTER_Z=0
UP_X=0
UP_Y=1
UP_Z=0
#Variables para dibujar los ejes del sistema
X_MIN=-500
X_MAX=500
Y_MIN=-500
Y_MAX=500
Z_MIN=-500
Z_MAX=500
ANG = math.degrees(math.atan2(EYE_Z, EYE_X))
ANG_incremento = 1.0 # incremento

#DimBoard = 200


pygame.init()

textures = []
filename = "Tex_plano.bmp"
filename2 = "obsidiana.bmp"
filename3 = "bandeja.bmp"
filename4 = "acat.bmp"
filename5 = "cofre.bmp"
filename6 = "frontal.bmp"
filename7 = "lateral.bmp"
filename8 = "trasera.bmp"
filename9 = "ventana.bmp"
filename10 = "arriba.bmp"
filename11 = "basuralat.bmp"
filename12 = "basurasup.bmp"
filename13 = "portal.bmp"


robots = {}
basuras = {}
incis = {}
lista_bas = []

print(lista)

def Init():
    pygame.display.set_mode(
        (screen_width, screen_height), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("OpenGL y Mesa: Limpiadores")


    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(FOVY, screen_width/screen_height, ZNEAR, ZFAR)


    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z)
    glClearColor(0,0,0,0)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
    
    Texturas(filename)
    Texturas(filename2)
    Texturas(filename3)
    Texturas(filename4)
    Texturas(filename5)
    Texturas(filename6)
    Texturas(filename7)
    Texturas(filename8)
    Texturas(filename9)
    Texturas(filename10)
    Texturas(filename11)
    Texturas(filename12)
    Texturas(filename13)
        
       
    for agent in lista[1]:
        basura = Basura((agent["x"]+1) * 7.9 ,( agent["z"]+1) * 7.9 )
        basuras[agent["id"]] = basura
        lista_bas.append(basura)
        
    for agent in lista[0]:
        print(basuras)
        robot = Robot((agent["x"]+1) * 7.9 , (agent["z"]+1) * 7.9 , lista_bas)
        robots[agent["id"]] = robot
    

def Texturas(filepath):
    textures.append(glGenTextures(1))
    id = len(textures) - 1
    glBindTexture(GL_TEXTURE_2D, textures[id])
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    image = pygame.image.load(filepath).convert()
    w, h = image.get_rect().size
    image_data = pygame.image.tostring(image, "RGBA")
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data)
    glGenerateMipmap(GL_TEXTURE_2D)

def lookAt():
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    gluLookAt(EYE_X, EYE_Y, EYE_Z, CENTER_X, CENTER_Y, CENTER_Z, UP_X, UP_Y, UP_Z)

    
def handle_input():
    global EYE_X, EYE_Z, CENTER_X, CENTER_Z, ANG

    keys = pygame.key.get_pressed()
    if keys[K_a]:
        ANG += ANG_incremento
        EYE_X = CENTER_X + RADIUS * math.cos(math.radians(ANG))
        EYE_Z = CENTER_Z + RADIUS * math.sin(math.radians(ANG))
        #CENTER_X -= 1
        lookAt()
    if keys[K_d]:
        ANG -= ANG_incremento
        #CENTER_X += 1
        EYE_X = CENTER_X + RADIUS * math.cos(math.radians(ANG))
        EYE_Z = CENTER_Z + RADIUS * math.sin(math.radians(ANG))
        lookAt()
        
       
                
def draw_incinerador():
    glPushMatrix()
    glColor3f(1, 1, 1)  # BLANCOOO
    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, textures[1])
    glTranslatef(200, 0.0, 200)
    glScalef(100.0, 30.0, 100.0)
    # Front face (turquoise)
    glBegin(GL_QUADS)
    #glColor3f(1.0, 0.0, 0.0)
    glTexCoord2f(0.0, 0.0)
    glVertex3f(-0.5, -0.5, 0.5)
    glTexCoord2f(0.0, 1.0)
    glVertex3f(0.5, -0.5, 0.5)
    glTexCoord2f(1.0, 1.0)
    glVertex3f(0.5, 0.5, 0.5)
    glTexCoord2f(1.0, 0.0)
    glVertex3f(-0.5, 0.5, 0.5)
    glEnd()

    # Back face (green)
    glBegin(GL_QUADS)
    glTexCoord2f(0.0, 0.0)
    #glColor3f(1.0, 0.0, 0.0)
    glVertex3f(-0.5, -0.5, -0.5)
    glTexCoord2f(0.0, 1.0)
    glVertex3f(0.5, -0.5, -0.5)
    glTexCoord2f(1.0, 1.0)
    glVertex3f(0.5, 0.5, -0.5)
    glTexCoord2f(1.0, 0.0)
    glVertex3f(-0.5, 0.5, -0.5)
    glEnd()
    glDisable(GL_TEXTURE_2D)

    # ARRIBA DEL PORTAL)
    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, textures[12])
    glBegin(GL_QUADS)
    glColor3f(1.0, 1.0, 1.0)
    
    glTexCoord2f(0.0, 0.0)
    
    glVertex3f(-0.5, 0.5, 0.5)
    glTexCoord2f(0.0, 1.0)
    glVertex3f(0.5, 0.5, 0.5)
    glTexCoord2f(1.0, 1.0)
    glVertex3f(0.5, 0.5, -0.5)
    glTexCoord2f(1.0, 0.0)
    glVertex3f(-0.5, 0.5, -0.5)
    glEnd()
    glDisable(GL_TEXTURE_2D)

    # Bottom face (magenta)
    glEnable(GL_TEXTURE_2D)
    glColor3f(1.0, 1.0, 1.0)
    glBindTexture(GL_TEXTURE_2D, textures[1])
    glBegin(GL_QUADS)
    glTexCoord2f(0.0, 0.0)
    #glColor3f(1.0, 0.0, 0.0)
    glVertex3f(-0.5, -0.5, 0.5)
    glTexCoord2f(0.0, 1.0)
    glVertex3f(0.5, -0.5, 0.5)
    glTexCoord2f(1.0, 1.0)
    glVertex3f(0.5, -0.5, -0.5)
    glTexCoord2f(1.0, 0.0)
    glVertex3f(-0.5, -0.5, -0.5)
    glEnd()

    # Left face (red)
    glBegin(GL_QUADS)
    #glColor3f(1.0, 0.0, 0.0)
    glTexCoord2f(0.0, 0.0)
    glVertex3f(-0.5, -0.5, 0.5)
    glTexCoord2f(0.0, 1.0)
    glVertex3f(-0.5, -0.5, -0.5)
    glTexCoord2f(1.0, 1.0)
    glVertex3f(-0.5, 0.5, -0.5)
    glTexCoord2f(1.0, 0.0)
    glVertex3f(-0.5, 0.5, 0.5)
    glEnd()

    # Right face (blue)
    glBegin(GL_QUADS)
    #glColor3f(1.0, 0.0, 0.0)
    glTexCoord2f(0.0, 0.0)
    glVertex3f(0.5, -0.5, 0.5)
    glTexCoord2f(0.0, 1.0)
    glVertex3f(0.5, -0.5, -0.5)
    glTexCoord2f(1.0, 1.0)
    glVertex3f(0.5, 0.5, -0.5)
    glTexCoord2f(1.0, 0.0)
    glVertex3f(0.5, 0.5, 0.5)
    glEnd()
    glDisable(GL_TEXTURE_2D)
    
    glPopMatrix()
    #glDisable(GL_TEXTURE_2D)
      
     
def display():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    #Se dibuja el plano gris
    draw_incinerador()
    glColor3f(1.0, 1.0, 1.0)
    glEnable(GL_TEXTURE_2D)

    # Cara frontal (plano texturizado)
    glBindTexture(GL_TEXTURE_2D, textures[12])
    #glColor3f(0.3, 0.3, 0.3)
    glBegin(GL_QUADS)
    glVertex3d(0, 0, 0)
    glVertex3d(0, 0, 400)
    glVertex3d(400, 0, 400)
    glVertex3d(400, 0, 0)
    glEnd()
    glDisable(GL_TEXTURE_2D)
    #Se dibuja los carros y las basuras
    """
    for robot in robots.values():
        robot.draw(textures)
    for basura in basuras.values():
        basura.draw(textures)
    """
       
    


    response = requests.get(URL_BASE + LOCATION)
    lista = response.json()
    for agent in lista[0]:
        robots[agent["id"]].draw(textures)
        robots[agent["id"]].update((agent["x"]+1 )* 7.9, (agent["z"]+1) * 7.9)
        #robots[agent["id"]].detectar_colision()
        robots[agent["id"]].detectar_colision_new()
        robots[agent["id"]].colision_inci() 
        for agent in lista[1]:
            basuras[agent["id"]].draw(textures)
            basuras[agent["id"]].update((agent["x"]+1 )* 7.9, (agent["z"]+1 )* 7.9)

   
done = False
Init()
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    handle_input()  # Manejar entrada del teclado
    display()


    pygame.display.flip()
    pygame.time.wait(100)


pygame.quit()
