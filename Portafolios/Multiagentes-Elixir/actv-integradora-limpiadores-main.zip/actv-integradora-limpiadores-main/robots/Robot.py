#Autor: Ivan Olmos Pineda
#Curso: Multiagentes - Graficas Computacionales


import pygame
from pygame.locals import *


# Cargamos las bibliotecas de OpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from objloader import *
import math

viewport = (800,600)
hx = viewport[0]/2
hy = viewport[1]/2
srf = pygame.display.set_mode(viewport, OPENGL | DOUBLEBUF)

glLightfv(GL_LIGHT0, GL_POSITION,  (-40, 100, 100, 0.0))
glLightfv(GL_LIGHT0, GL_AMBIENT, (0.8, 0.8, 0.8, 1.0))
glLightfv(GL_LIGHT0, GL_DIFFUSE, (0.8, 0.8, 0.8, 1.0))
glEnable(GL_LIGHT0)
glEnable(GL_LIGHTING)
glEnable(GL_COLOR_MATERIAL)
glEnable(GL_DEPTH_TEST)
glShadeModel(GL_SMOOTH)           # most obj files expect to be smooth-shaded

# LOAD OBJECT AFTER PYGAME INIT
#obj = OBJ(sys.argv[1], swapyz=True)
obj = OBJ("car.obj", swapyz=True)
obj.generate()

bandeja_sub = 0
acomodo = 0.0
sphere = gluNewQuadric()
class Robot:
   
    def __init__(self, x, z, basuras):
        self.colision_detectada = False
        self.basuras = basuras
        #Se inicializa las coordenadas de los vertices del cubo
        self.vertexCoords = [  
                   1,1,1,   1,1,-1,   1,-1,-1,   1,-1,1,
                  -1,1,1,  -1,1,-1,  -1,-1,-1,  -1,-1,1  ]
        #Se inicializa los colores de los vertices del cubo
        self.vertexColors = [
                   1,1,1,   1,0,0,   1,1,0,   0,1,0,
                   0,0,1,   1,0,1,   0,0,0,   0,1,1  ]
        #Se inicializa el arreglo para la indexacion de los vertices
        self.elementArray = [
                  0,1,2,3, 0,3,7,4, 0,4,5,1,
                  6,2,1,5, 6,5,4,7, 6,7,3,2  ]

        self.bandeja_pos = -0.5
        self.Position = [x, 5.0, z]
        self.angulo_inc=1
        self.Direction=[0,0,0]
        self.colision = 1
        self.vect_temp=[0,0,0]
       
    def detectar_colision(self):
        if not self.colision_detectada:  # Verificar si una colisión ya fue detectada
            for obj_basura in self.basuras:
                # Obtener las posiciones de los objetos y calcular la distancia
                pos_carro = self.Position
                pos_basura = obj_basura.Position # La altura de la basura es 1
                #pos_basura = [obj_basura.x, 1, obj_basura.y]  # La altura de la basura es 1
                distancia = math.sqrt((pos_carro[0] - pos_basura[0])**2 + (pos_carro[2] - pos_basura[2])**2)
                #suma_radios = self.radio + obj_basura.radio
                suma_radios = 5
                print ("Pos_carro: ", pos_carro)
                print ("Pos_basura: ", pos_basura)
                if distancia < suma_radios:
                    print("Colisión detectada")
                    print ("Basura Colisionada: ", pos_basura)
                    
                    obj_basura.colision = 1 # Establece colisión en 1
                    #obj_basura.Position[1] = 0.5  # Modifica la posición de la "bandeja"
                    # Elimina la basura de la lista original
                    self.basuras.remove(obj_basura)
                    self.colision_detectada = True  #estado de colision
                    self.colision=2
        
    def detectar_colision_new(self):
        if not self.colision_detectada:  # Verificar si una colisión ya fue detectada
            for obj_basura in self.basuras:
                # Obtener las posiciones de los objetos y calcular la distancia
                pos_carro = self.Position
                pos_basura = obj_basura.Position # La altura de la basura es 1
                if pos_carro == pos_basura:
                    obj_basura.colision = 1 # Establece colisión en 1
                    self.basuras.remove(obj_basura)
                    self.colision_detectada = True  #estado de colision
                    self.colision=2
                    
    def colision_inci(self):
        if self.colision==3:
            pos_carro = self.Position
            distancia = math.sqrt((pos_carro[0] - 200) **2 + (pos_carro[2] - 200)**2)
            suma_radios = 70
            
            if distancia < suma_radios:
                print("CENTRO")
                print("CENTRO")
                print("CENTRO")
                print("CENTRO")
                print("CENTRO")
                print("CENTRO")
                print("CENTRO")
                print("CENTRO")
                self.colision_detectada = False #estado de colision
                self.colision=1
                    


    def calcular_nuevo_vector_direccion(self, new_x,new_z):
        #Calcular el vector hacia la direccion futura
        nueva_direccion = [new_x, 1, new_z]
        carro_x, carro_z = self.Position[0], self.Position[2]
        vector_con_direccion = [nueva_direccion[0] - carro_x, 0, nueva_direccion[2] - carro_z]
        
        # Normalizar el vector
        magnitude = math.sqrt(vector_con_direccion[0] ** 2 + vector_con_direccion[2] ** 2)
        
        if magnitude > 0:
            vector_con_direccion = [vector_con_direccion[0] / magnitude, 0, vector_con_direccion[2] / magnitude]
        
        #Establecer el nuevo vector de dirección
        velocidad_deseada = 4.0  
        self.Direction = [vector_con_direccion[0] * velocidad_deseada, 0, vector_con_direccion[2] * velocidad_deseada]
        
    
    def update(self, new_x, new_z):
            
        self.calcular_nuevo_vector_direccion(new_x,new_z)
        self.Position[0] = new_x
        self.Position[2] = new_z
        self.angulo_inc +=20
        #self.Position[0] += self.Direction[0]
        #self.Position[2] += self.Direction[2]
                
    def draw(self, texture_id):
        if self.colision == 1:
            self.bandeja_pos = -0.5
            
       # if self.Position[0] >= 50:
        #    self.colision = 2
         #   self.Direction[0] = 0
    
        elif self.colision == 2:
            print("ola bola")
            self.bandeja_pos += 0.1
            if self.bandeja_pos >= 0.5:
                self.colision = 3
        """
        elif self.colision == 3 and (self.Position[0] < 220 and self.Position[0] > 180) and (self.Position[2] < 220 and self.Position[2] > 180 ):
            self.colision = 1
            self.colision_detectada = False
        """
        glPushMatrix()
        
        glTranslatef(self.Position[0], self.Position[1], self.Position[2])
        
        
        car_direction = [self.Direction[0], self.Direction[1], self.Direction[2]]
        magnitude = math.sqrt(car_direction[0] ** 2 + car_direction[2] ** 2)
        if magnitude > 0:
            car_direction[0] /= magnitude
            car_direction[2] /= magnitude
        else:
            car_direction = [0, 0, 1]

        # Calcular el ángulo de rotación para que la bandeja apunte en la dirección correcta
        angle = math.degrees(math.atan2(car_direction[0], car_direction[2]))

        glRotatef(angle - 90, 0, 1, 0)  # Rotar la bandeja en la dirección del carro
        

        glScalef(10.0, 10.0, 10.0)
        glRotatef(270, 1, 0, 0)
        
        #glRotatef(angulo_demo, 0, 0, 1)
        # Dibuja el cuerpo del robot (un cubo)
        glTranslatef(0, 0, 0.75)
        
        #if self.colision != 1:
         #   glTranslatef(-1, 0, 0)  # Elevar el cubo en el eje Y

        glColor3f(1.0, 1.0, 1.0)
        glEnable(GL_TEXTURE_2D)

        glBindTexture(GL_TEXTURE_2D, texture_id[4])
        # Front face (turquoise)
        glBegin(GL_QUADS)
        #glColor3f(0.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.5, -0.5, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, 0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, 0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, 0.5)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0)
        #glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.5, -0.5, -0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0)
        #glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.5, 0.5, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, 0.5, 0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0)
        #glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.5, -0.5, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, 0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, -0.5, -0.5)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        #glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, 0.5, -0.5)
        glVertex3f(-0.5, 0.5, 0.5)
        glEnd()

        # Right face (blue)
        glBegin(GL_QUADS)
        #glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0.5, 0.5, -0.5)
        glVertex3f(0.5, 0.5, 0.5)
        glEnd()
        
        glDisable(GL_TEXTURE_2D)
        glColor3f(1.0, 1.0, 1.0)  
        glEnable(GL_TEXTURE_2D)

        glBindTexture(GL_TEXTURE_2D, texture_id[2])

        # Dibuja la bandeja
        glPushMatrix()
        glTranslatef(1, 0, self.bandeja_pos)  # Posicionar la bandeja debajo
        #glTranslatef(1, 0, -0.5)  # Posicionar la bandeja debajo
        #glColor3f(1.0, 1.0, 0.0)  # Color amarillo
        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.8, -0.5, 0.0)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.8, -0.5, 0.0)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.8, 0.5, 0.0)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.8, 0.5, 0.0)
        glEnd()
        
        glDisable(GL_TEXTURE_2D)
        
        if self.colision != 1 :
            glPushMatrix()
        
            glTranslatef(0.0,0.0,0.5) 
            glRotatef(90, 1,0,0)

            
            # Front face (turquoise)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[10])
            glColor3f(1.0, 1.0, 1.0)
            glBegin(GL_QUADS)

            # Coordenadas de textura invertidas verticalmente
            glTexCoord2f(0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)

            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)

            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, 0.5)

            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, 0.5)

            glEnd()
            



            # Back face (green)
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 1.0)
            #glColor3f(0.0, 1.0, 0.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)

            # Top face (yellow)
            
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[11])
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 0.0)
            glColor3f(1.0, 1.0, 1.0)
            glVertex3f(-0.5, 0.5, 0.5)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(0.5, 0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)
            
            

            # Bottom face (magenta)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture_id[10])
            glBegin(GL_QUADS)
            glTexCoord2f(0.0, 1.0)
            #glColor3f(1.0, 0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glEnd()

            # Left face (red)
            glBegin(GL_QUADS)
            #glColor3f(1.0, 0.0, 0.0)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(-0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(-0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(-0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(-0.5, 0.5, 0.5)
            glEnd()

            # Right face (blue)
            glBegin(GL_QUADS)
            #glColor3f(0.0, 0.0, 1.0)
            glTexCoord2f(0.0, 1.0)
            glVertex3f(0.5, -0.5, 0.5)
            glTexCoord2f(1.0, 1.0)
            glVertex3f(0.5, -0.5, -0.5)
            glTexCoord2f(1.0, 0.0)
            glVertex3f(0.5, 0.5, -0.5)
            glTexCoord2f(0.0, 0.0)
            glVertex3f(0.5, 0.5, 0.5)
            glEnd()
            glDisable(GL_TEXTURE_2D)
            
            glPopMatrix()
            #glDisable(GL_TEXTURE_2D)
            
            
        glPopMatrix()
        
        
        
        #la cajuela
        glPushMatrix()
        glTranslatef(-1.5, 0.0, 0.5) 
        glPushMatrix()
        glScalef(2.0, 1.2, 1.75)
        glRotatef(270, 1, 0, 0)
        # Dibuja el cuerpo del CARRO (un cubo)
        

        # lATERAL
        glColor3f(1.0, 1.0, 1.0)
        glEnable(GL_TEXTURE_2D)

        glBindTexture(GL_TEXTURE_2D, texture_id[6])
        glBegin(GL_QUADS)
        #glColor3f(0.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.5, -0.3, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, 0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, 0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, 0.5)
        glEnd()
        glDisable(GL_TEXTURE_2D)
        
        
        

        # LATERAL DERECHO
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id[6])
        
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.5, -0.3, -0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glEnd()
        glDisable(GL_TEXTURE_2D)

        # Top face (yellow)
        
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id[4])
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.5, 0.5, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, 0.5, 0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glEnd()
        glDisable(GL_TEXTURE_2D)

        # arriba
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id[9])
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.5, -0.3, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, 0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, -0.3, -0.5)
        glEnd()
        glDisable(GL_TEXTURE_2D)

        # Trasera
        
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id[7])
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(-0.5, -0.3, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(-0.5, -0.3, -0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(-0.5, 0.5, 0.5)
        glEnd()
        glDisable(GL_TEXTURE_2D)

        # Right face (blue)
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id[5])
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 1.0)
        glTexCoord2f(0.0, 0.0)
        glVertex3f(0.5, -0.5, 0.5)
        glTexCoord2f(0.0, 1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glTexCoord2f(1.0, 1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glTexCoord2f(1.0, 0.0)
        glVertex3f(0.5, 0.5, 0.5)
        glEnd()
        glDisable(GL_TEXTURE_2D)

        glPopMatrix()
        
        #tubo arriba
        glPushMatrix()
        glTranslatef(0.9,0.35,1.0)
        glScalef(0.5, 0.5, 2.0)
        
        # Front face (turquoise)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Right face (blue)
        glBegin(GL_QUADS)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix()
        
        
        #ESCAPE izquierdo
        glPushMatrix()
        glTranslatef(-1.2,0.45,-0.75)
        glScalef(1.3, 0.5, 0.2)
        
        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()
        
        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix() #fin DE Escape izquierdo
        
        
        #ESCAPE derecho
        glPushMatrix()
        glTranslatef(-1.2,-0.45,-0.75)
        glScalef(1.3, 0.5, 0.2)
        
        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()
        
        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        glBegin(GL_QUADS)
        glColor3f(0.5, 0.5, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix() #fin DE Escape derecho
        
        #ALAAAASSSSSS
        #ala derecha
        glPushMatrix()
        glTranslatef(0.5,-0.5,0.5)
        glScalef(1.5, 1.5, 0.2)
        
        # Front face (turquoise)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Right face (blue)
        glBegin(GL_QUADS)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix()
        
        
        #ala izquierda
        glPushMatrix()
        glTranslatef(0.5,0.5,0.5)
        glScalef(1.5, 1.5, 0.2)
        
        # Front face (turquoise)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()
        # Right face (blue)
        glBegin(GL_QUADS)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix()
        
        
        #Spoilersss
        #base drecha
        glPushMatrix()
        glTranslatef(-1.0,-0.5,0.5)
        glScalef(0.15, 0.15, 0.6)
        glRotatef(15,0.0, 1.0,0.0)
        
        # Front face (turquoise)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Right face (blue)
        glBegin(GL_QUADS)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix()
        
        #base izquierda
        glPushMatrix()
        glTranslatef(-1.0,0.5,0.5)
        glScalef(0.15, 0.15, 0.6)
        glRotatef(15,0.0, 1.0,0.0)
        
        # Front face (turquoise)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Right face (blue)
        glBegin(GL_QUADS)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix()
        
        
        #parte arriba
        glPushMatrix()
        glTranslatef(-1.1,0.0,0.68)
        glScalef(1.15, 2.15, 0.2)
        glRotate(25,0.0,1.0,0.0)
        
        # Front face (turquoise)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Back face (green)
        glBegin(GL_QUADS)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Top face (yellow)
        glBegin(GL_QUADS)
        glColor3f(1.0, 1.0, 0.0)
        glVertex3f(-0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glEnd()

        # Bottom face (magenta)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 1.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glEnd()

        # Left face (red)
        glBegin(GL_QUADS)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(-0.25, -0.25, 0.25)
        glVertex3f(-0.25, -0.25, -0.25)
        glVertex3f(-0.25, 0.25, -0.25)
        glVertex3f(-0.25, 0.25, 0.25)
        glEnd()

        # Right face (blue)
        glBegin(GL_QUADS)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.25, -0.25, 0.25)
        glVertex3f(0.25, -0.25, -0.25)
        glVertex3f(0.25, 0.25, -0.25)
        glVertex3f(0.25, 0.25, 0.25)
        glEnd()

        glPopMatrix()
        
        
        
        glPopMatrix() #fin de la cajuela


        
        glTranslatef(0, 0, -0.25)
        # Dibuja las ruedas
        glColor3f(1.0, 1.0, 1.0)  
        wheelRadius = 0.25
        
        glEnable(GL_TEXTURE_2D)

        # Cara frontal (plano texturizado)
        glBindTexture(GL_TEXTURE_2D, texture_id[0])


        glPushMatrix()
        glTranslatef(-1.5, -0.5, 0)  # Rueda izquierda trasera
        gluSphere(sphere, wheelRadius, 32, 26)
        glPopMatrix()

        glPushMatrix()
        glTranslatef(0.5, -0.5, 0)  # Rueda derecha trasera
        gluSphere(sphere, wheelRadius, 32, 26)
        glPopMatrix()
        glPushMatrix()
        glTranslatef(-1.5, 0.5, 0)  # Rueda izquierda delantera
        gluSphere(sphere, wheelRadius, 32, 26)
        glPopMatrix()

        glPushMatrix()
        glTranslatef(0.5, 0.5, 0)  # Rueda derecha delantera
        gluSphere(sphere, wheelRadius, 32, 26)
        glPopMatrix()
        
        
        glDisable(GL_TEXTURE_2D)
        
        
        #dibujado de los faros
        glColor3f(1.0, 1.0, 0.0)  
        glPushMatrix() 
        glTranslatef(0.45, 0.5, 0.5)   #faro izquierdo
        gluSphere(sphere, 0.1, 32, 26)
        glPopMatrix()
        
        glPushMatrix()
        glTranslatef(0.45, -0.5, 0.5)  #faro derecho
        gluSphere(sphere, 0.1, 32, 26)
        glPopMatrix()
        
        glPopMatrix()
        #glDisable(GL_TEXTURE_2D)