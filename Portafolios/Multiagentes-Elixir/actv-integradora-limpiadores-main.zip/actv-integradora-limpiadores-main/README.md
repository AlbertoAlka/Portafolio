# actv-integradora-limpiadores

## Manual de Ejecucion

### Paso 1:
Ejecutar backend.py [python backend.py]

### Paso 2:
Copiar la Dirección IP del servidor mostrada en la Terminal (la última, la que esta encima de "Press CTRL+C to quit"), dentro del archivo Limpiadores.py en la línea 17 [(p/e) URL_BASE = "http://10.50.80.219:5100"]

### Paso 3:
Ejecutar Limpiadores.py al mismo tiempo que el backend.py, es decir, en otra terminal.
