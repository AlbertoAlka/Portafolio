#ifndef HITBOX_H
#define HITBOX_H


class hitbox
{
    public:

        // Variables de la Hitbox
        float centro[3];
        float extend[3];

        // Creacion de la hitbox
        hitbox(const float ancho, const float alto, const float prof, const float c[3]);
        virtual ~hitbox();

    protected:

    private:
};

#endif // HITBOX_H
