#ifndef ESCUDO_H
#define ESCUDO_H

#include <unistd.h>
#ifdef APPLE
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdlib.h>
#include <math.h>
#define PI 3.14159265


#include <GL/glut.h>
#include <stdio.h>

#include <random>
#include <iomanip>


#include <math.h>
#include <random>
#include <iomanip>
#include <GL/glut.h>
#include <iostream>

#include "hitbox.h"

struct Vector {
    double x, y;

    Vector(double x = 0, double y = 0): x(x), y(y) {}

    Vector operator+(const Vector& v) const {
        return Vector(x + v.x, y + v.y);
    }

    Vector operator-(const Vector& v) const {
        return Vector(x - v.x, y - v.y);
    }

    Vector operator*(double s) const {
        return Vector(x * s, y * s);
    }

    double operator*(const Vector& v) const {
        return x * v.x + y * v.y;
    }

    double operator%(const Vector& v) const {
        return x * v.y - y * v.x;
    }

    double length() const {
        return sqrt(x * x + y * y);
    }

    void normalize() {
        double l = length();
        x /= l;
        y /= l;
    }

    double angle() const {
        return atan2(y, x);
    }

    void rotate(double angle) {
        double c = cos(angle), s = sin(angle);
        double nx = c * x - s * y;
        double ny = s * x + c * y;
        x = nx; y = ny;
    }
};

class escudo // Clase Escudo
{
    public:
        escudo();
        void draw(hitbox* caja); // Dibujado del Escudo
        void update(int key); // Movimiento del escudo, por jugador
        virtual ~escudo();

        float centro_escudo[3];
        float x_escudo;
        float y_escudo;
        float z_escudo;

        float control_x;

        float anguloX; // Angulo en X
        float anguloY; // Angulo en Y
        float deltaGiro; // Giro del Escudo

        // Setters y Getters de Posici�n Horizontal
        void set_posesc_hor(float n);
        float get_posesc_hor();

        // Setters y Getters de Possicion en Y
        void set_posescy(float n);
        float get_posescy();

        // Setters y Getters de Posicion vertical
        void set_posesc_ver(float n);
        float get_posesc_ver();

        float posesc_hor; // Posicion Horizontal
        float posescy; // Posicion en Y
        float posesc_ver; // Posicion Vertical

    protected:

    private:
        // Variables del Escudo

};

#endif // ESCUDO_H
