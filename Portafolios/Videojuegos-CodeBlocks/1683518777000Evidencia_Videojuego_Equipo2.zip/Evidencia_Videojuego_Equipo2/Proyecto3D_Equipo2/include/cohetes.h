#ifndef COHETES_H
#define COHETES_H

#include <unistd.h>
#ifdef _APPLE_
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdlib.h>
#include <math.h>
#define PI 3.14159265


#include <GL/glut.h>
#include <stdio.h>

#include <random>
#include <iomanip>


#include <math.h>
#include <random>
#include <iomanip>
#include <GL/glut.h>
#include <iostream>

#include <stdlib.h>

#include "hitbox.h"

using namespace std;


class cohetes // Clase Cohetes
{
    private: // Variables del Cohete
        float cohete_x; // Posicion en x
        float cohete_y; // Posicion en y

        float translatefA; // Traslacion A
        float translatefB; // Traslacion B

    public:
        cohetes();
        virtual ~cohetes();
        void drawCohetes(hitbox* cajadelcoehete); // Dibujado de los Cohetes

        // Setters y Getters
        void set_cohete_x(float x);
        float get_cohete_x();

        void set_cohete_y(float y);
        float get_cohete_y();

        void set_translatefA(float n);
        float get_translatefA();

        void set_translatefB(float n);
        float get_translatefB();

        // Matriz Centro del Cohete
        float centrocohete [3];

    protected:

};

#endif // COHETES_H
