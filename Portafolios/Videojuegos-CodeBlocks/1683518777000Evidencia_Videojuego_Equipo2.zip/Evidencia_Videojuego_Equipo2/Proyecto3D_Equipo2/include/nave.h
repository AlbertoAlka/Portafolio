#ifndef NAVE_H
#define NAVE_H

#include <unistd.h>
#ifdef _APPLE_
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdlib.h>
#include <math.h>
#define PI 3.14159265


#include <GL/glut.h>
#include <stdio.h>

#include <random>
#include <iomanip>


#include <math.h>
#include <random>
#include <iomanip>
#include <GL/glut.h>
#include <iostream>

#include "hitbox.h"

using namespace std;

class nave // Clase Nave
{
    public: // Funciones de la Nave
        nave();
        virtual ~nave();
        void drawNave(hitbox* caja_cohe); // Dibujado
        void updateNave(); // Movimiento

        // Setters y Getters de Posici�n Horizontal
        void set_posnave_hor(float n);
        float get_posnave_hor();

        // Setters y Getters de Possicion en Y
        void set_posnavey(float n);
        float get_posnavey();

        // Setters y Getters de Posicion vertical
        void set_posnave_ver(float n);
        float get_posnave_ver();

        // Setters y Getters de Rotacion 1 y 2 de la Nave
        void set_naverot(float n);
        float get_naverot();
        void set_naverot2(float n);
        float get_naverot2();

        float posnave_hor; // Posicion Horizontal
        float posnavey; // Posicion en Y
        float posnave_ver; // Posicion Vertical

        float naverot2; // Rotacion 2

        float centrocohete [3]; // Centro de la figura del cohete

    protected:

    private: // Variables de la Nave

        // Variables del Cohete construido desde Nave
        float xcoh1; // Movimiento de Cohete 1
        //float xcoh2; // Movimiento de Cohete 2
        //float xcoh3; // Movimiento de Cohete 3
        //float xcoh4;

};

#endif // NAVE_H
