#include <unistd.h>
#ifdef _APPLE_
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdlib.h>
#include <math.h>
#define PI 3.14159265

#include <stdio.h>

#include <random>
#include <iomanip>

#include <iostream>

#include "nave.h" // Incluye Clase Nave
#include "cohetes.h" // Incluye Clase Cohete
#include "escudo.h" // Incluye Clase Escudo

#include "RgbImage.h" // Incluye Texturas

#include "hitbox.h" // Incluye Colisiones

//se define la cantidad de texturas que se manejaran
#define NTextures 3
GLuint	texture[NTextures];

using namespace std;

// Llamada a los archivos de las texturas
char* filename0 = "textura1.bmp";
char* filename1 = "void.bmp";
char* filename2 = "dirt.bmp";

const float RADIO_NAVE = 1.0f; // Radio de la Nave
const float RADIO_COHETE = 0.5f; // Radio del Cohete
bool colision = false; // variable que indica si hay colisi�n
bool colision_esc = false; // Colision del escudo
float centrocohete [3]; // Centro del cohete
float n1=0;
float n2=0;

float centro_escudo[3]; // Centro del escudo

nave nav; // Crea Objeto Nave

escudo esc; // Crea Objeto Escudo

GLfloat anguloSol = 0.0f; // Angulo inicial del Planeta

float navrot; // Rotaci�n de la Nave 1
float navrot2; // Rotaci�n de la Nave 2

GLint ancho, alto; // Ancho y Alto de la Perspectiva de la Camara
int hazPerspectiva = 1; // Cambio de la Perspectiva

float radio = 1.5; // Radio de la �rbita

//Variables para definir la posicion del observador
//gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z)

// Variables que definen la posici�n del la c�mara
        float EYE_X;
        float EYE_Y;
        float EYE_Z;
        float CENTER_X;
        float CENTER_Y;
        float CENTER_Z;
        float UP_X;
        float UP_Y;
        float UP_Z;

 // Carga de Textura
 void loadTextureFromFile(char *filename, int index)
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
	//glEnable(GL_DEPTH_TEST);

	RgbImage theTexMap( filename );

    //generate an OpenGL texture ID for this texture
    glGenTextures(1, &texture[index]);
    //bind to the new texture ID
    glBindTexture(GL_TEXTURE_2D, texture[index]);


    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, theTexMap.GetNumCols(), theTexMap.GetNumRows(), 0,
                     GL_RGB, GL_UNSIGNED_BYTE, theTexMap.ImageData());
    theTexMap.Reset();
}

// Funci�n que cambia la perspectiva de la c�mara
void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if(hazPerspectiva==1){
      gluPerspective(60.0f, (GLfloat)width/(GLfloat)height, 1.0f, 80.0f);
        float EYE_X=-25.0;
        float EYE_Y=15.0;
        float EYE_Z=15.0;
        float CENTER_X=0;
        float CENTER_Y=0;
        float CENTER_Z=0;
        float UP_X=0;
        float UP_Y=1;
        float UP_Z=0;
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z);
        ancho = width;
        alto = height;
    }
    else if(hazPerspectiva==0){
        gluPerspective(60.0f, (GLfloat)width/(GLfloat)height, 1.0f, 80.0f);
        EYE_X = 0.0;
        EYE_Y = 25.0;
        EYE_Z = 0.0;
        CENTER_X = 0.0;
        CENTER_Y = 0.0;
        CENTER_Z = 0.0;
        UP_X = 0.0;
        UP_Y = 0.0;
        UP_Z = -1.0;
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z);
        ancho = width;
        alto = height;
    }
}

// Cambios del color del sol respecto a la colision
float sol_explotadinho_a=0.9;
float sol_explotadinho_b=0.8;
float sol_explotadinho_c=0.0;

// Centro del sol
float centro_sol[3];

// Dibuja a la Tierra
void drawEarth()
{
    //activando texturas
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glRotatef(90, 1.0f, 0.0f, 0.0f);
    glRotatef(anguloSol, 0.0f, 0.0f, 1.0f);

    glTranslatef(0, 0, 0);

    glColor3f(1.0,1.0,1.0);
    glBindTexture(GL_TEXTURE_2D, texture[2]); // Se le atribuye una textura
    GLUquadric *qobj = gluNewQuadric();
    gluQuadricTexture( qobj, GL_TRUE );
    gluSphere( qobj, 2.0f, 20, 20 );
    gluDeleteQuadric( qobj );
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
 }

// Funci�n que dibuja al Planeta en el escenario
void Sol(hitbox* caja)
{
    //activando texturas
    //glEnable(GL_TEXTURE_2D);

     glPushMatrix();
     glRotatef(90, 1.0f, 0.0f, 0.0f);
     glRotatef(anguloSol, 0.0f, 0.0f, 1.0f);
     glColor3f(sol_explotadinho_a,sol_explotadinho_b,sol_explotadinho_c); // Color
     glutWireSphere(2.5f,20,20);

    /*glBindTexture(GL_TEXTURE_2D, texture[0]);
    GLUquadric *qobj = gluNewQuadric();
    gluQuadricTexture( qobj, GL_TRUE );
    gluSphere( qobj, 2.5f, 20, 20 );
    gluDeleteQuadric( qobj );*/

     glPopMatrix();

     // Construir centro del sol
    centro_sol[0]=0.0;
    centro_sol[1]=0.0;
    centro_sol[2]=0.0;
    // Hitbox del sol
    *caja = hitbox(2.5f, 2.5f, 2.5f, centro_sol);

     //glDisable(GL_TEXTURE_2D);
 }

 //sol explotado
void Sol(hitbox* caja, float a, float b, float c )
{
     glPushMatrix();
     glRotatef(90, 1.0f, 0.0f, 0.0f);
     glRotatef(anguloSol, 0.0f, 0.0f, 1.0f);
    glColor3f(a,b,c);

     glutWireSphere(2.5f,20,20);
     glPopMatrix();
     // Centro sol
    centro_sol[0]=0.0;
    centro_sol[1]=0.0;
    centro_sol[2]=0.0;
    // Hitbox del sol
    *caja = hitbox(2.5f, 2.5f, 2.5f, centro_sol);
 }

// Funci�n para detectar colisiones
bool detectCollision(hitbox caja1, hitbox caja2, float radius1, float radius2) {
    float distance = sqrt(pow((caja2.centro[0] - caja1.centro[0]), 2) + pow((caja2.centro[1] - caja1.centro[1]), 2) + pow((caja2.centro[2] - caja1.centro[2]), 2));
    return (distance < (radius1 + radius2));
}

// Crear objetos tipo hitbox
hitbox caja_sol(2.5f, 2.5f, 2.5f, centro_sol);
hitbox caja_cohete(0.25f, 0.25f, 0.25f, centrocohete);
hitbox caja_escud(1.0f, 1.0f, 1.0f, centro_escudo);

// Contador de las vidas del planeta
int contador_vidas=0;

// Angulo de rotacion nave
float anguloo=0.0;
int last_random_time = 0; //para que no sea imposible

float ultimacol=0;

int randomAnglenorte() {
    return (rand() / (double)RAND_MAX) * 180.0;  // Genera un n�mero entre 0 y 180
}
int randomAnglesur() {
    return ((rand() / (double)RAND_MAX) * 180.0) + 180.0; //Numero entre 180 y 360
}

// Variable distancia entre nave y escudo
float distancia_escnav;

// Display del juego
void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glColor3f(1.0f, 0.0f, 0.0f);

    // Conversion del movimiento del escudo para angulos siempre positivo
    if (esc.control_x < 0){
        esc.control_x +=360;
    }

    Sol(&caja_sol); // Dibujado del Planeta
    drawEarth(); // Nucleo del Planeta
    esc.draw(&caja_escud); // Dibujado del Escudo
    nav.drawNave(&caja_cohete); // Dibujado de la Nave

    // Distancia entre nave y escudo
    distancia_escnav = nav.get_naverot2() - esc.control_x;

    cout << "***************************************************" << endl;

    // Detector de colision entre escudo y cohete
    if (detectCollision(caja_escud,  caja_cohete, 5.0, 2.5)){
        if (distancia_escnav<=25 and distancia_escnav>=-25){
            colision_esc=true;
            cout<<"hay colision con el ESCUDO +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
            ultimacol=nav.get_naverot2();
        }
    }
    else{
        colision_esc=false;
        cout << "NO hay colision con el escudo" << endl;
            };

    // Detector de colision entre cohete y planeta
    if (detectCollision(caja_cohete, caja_sol, 0.5, 2)){
        colision=true;
        cout << "hay colision con el SOL ---------------------------------------------------------------------"<< endl ;
    }
    else{
        colision=false;
    cout << "NO hay colision con el sol" << endl;
            };

    cout << "Distancia del Escudo con la Nave: " << distancia_escnav<< endl;

    cout<< "Centro del Cohete: " << caja_cohete.centro[0] << endl;

    cout << endl;

    cout << "Angulo del Escudo: " << esc.anguloX << endl;

    cout << endl;

    // Si el cohete colisiona con el escudo se regresa a su estado anterior
    if (colision_esc == true) {
        nav.posnave_hor = -18;
    }

    // Si el cohete colisiona con el planeta, su vida disminuye
    if (colision==true){
        nav.posnave_hor=-18;

        if (contador_vidas<1){

            sol_explotadinho_a=0.9;
            sol_explotadinho_b=0.7;
            sol_explotadinho_c=0.2;

        } else if (contador_vidas<2){
            sol_explotadinho_a=0.8;
            sol_explotadinho_b=0.5;
            sol_explotadinho_c=0.0;

        } else if (contador_vidas<=3){
            sol_explotadinho_a=1.0;
            sol_explotadinho_b=0.0;
            sol_explotadinho_c=0.0;
        }
        contador_vidas +=1;
    }

    // Game Over / Cambio de textura del planeta
    if (contador_vidas>3){
        usleep(9000);
        loadTextureFromFile(filename0,2);
    }

    // Movimiento del Planeta
    (anguloSol + 0.6 < 360.0) ? anguloSol += 0.6f : anguloSol = 0.0f; // Rotaci�n del Planeta

    nav.updateNave(); // Movimiento de la Nave

    // Comportamiento Random de la Nave
     int current_time = glutGet(GLUT_ELAPSED_TIME);

      // Verificar si han pasado al menos 5 segundos desde la �ltima vez que se gener� un n�mero aleatorio
      if (current_time - last_random_time >= 5200) {
        // Generar un n�mero aleatorio entre 0 y 360
        //nav.set_naverot2(rand() % 361);
          if (ultimacol<=180){
              nav.set_naverot2(randomAnglesur());
          } else{
              nav.set_naverot2(randomAnglenorte());
          }

        // Actualizar la variable global last_random_time con el tiempo actual
        last_random_time = current_time;
      }

      //nav.set_naverot2(100);

    cout << "Angulo del Escudo X: " << esc.anguloX << endl;
    cout << "Rotacion de la Nave 2: " <<  nav.get_naverot2()<<endl;

    cout << "_____________________________________________________" << endl;

    usleep(7000);
}

// Inicializaci�n del juego
void init()
{
    glClear(GL_COLOR_BUFFER_BIT);

   glEnable(GL_DEPTH_TEST);
    srand(static_cast<unsigned int>(time(nullptr)));
   ancho = 600; // Posici�n Inicial de la camara
   alto = 600; // Posici�n Inicial de la camara

    nav.set_posnave_hor(-7); // Posici�n Inicial de la Nave

    navrot = nav.get_naverot(); // Rotacion de la Nave 1
    navrot2 = nav.get_naverot2(); // Rotacion de la Nave 2

    // Creacion de Texturas
    loadTextureFromFile(filename0,0);
    loadTextureFromFile(filename1,1);
    loadTextureFromFile(filename2,2);

}

// Funcion para ciclo infinito
void idle()
{
     display();
 }

// Movimientos del Jugador
void keyboard(unsigned char key, int x, int y)
{
    switch(key)
        {
        case 'd':
        case 'D':
            esc.update(2);
            break;

        case 'a':
        case 'A':
            esc.update(3);
            break;

        case 'p':
        case 'P':
            hazPerspectiva=1;
            reshape(ancho,alto);
            break;

        case 'o':
        case 'O':
            hazPerspectiva=0;
            reshape(ancho,alto);
            break;

        case 27:   // escape
            exit(0);
            break;

        default:
            break;
    }

}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowPosition(100, 100);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Juego Protege al planeta");
    init();
    glutDisplayFunc(display); // Llamada al Display
    glutReshapeFunc(reshape); // Llamada a colocar la posici�n de la c�mara
    glutIdleFunc(idle); // Llamada al ciclo infinito
    glutKeyboardFunc(keyboard); // Llamada a los movimientos del jugador

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glutMainLoop();
    return 0;
}
