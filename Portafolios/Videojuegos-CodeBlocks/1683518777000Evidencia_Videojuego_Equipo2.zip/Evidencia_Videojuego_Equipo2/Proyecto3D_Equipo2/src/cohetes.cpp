#include "cohetes.h"

cohetes::cohetes() // Constructor del Cohete
{
    cohete_x = 0.0;
    cohete_y = 0.0;

    translatefA=0.0;
    translatefB=0.0;
}

cohetes::~cohetes()
{
    //dtor
}

void cohetes::set_cohete_x(float x) {
    cohete_x = x;
}
float cohetes::get_cohete_x() {
    return cohete_x;
}

void cohetes::set_cohete_y(float y) {
    cohete_y = y;
}
float cohetes::get_cohete_y() {
    return cohete_y;
}

void cohetes::set_translatefA(float n) {
    translatefA = n;
}
float cohetes::get_translatefA() {
    return translatefA;
}

void cohetes::set_translatefB(float n) {
    translatefB = n;
}
float cohetes::get_translatefB() {
    return translatefB;
}

void cohetes::drawCohetes(hitbox* cajadelcohete) {
    glPushMatrix();
    glTranslatef(0.0, translatefA, translatefB); // Traslacion del Cohete
    glScalef(0.2, 0.2, 0.2);
    //glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
    glRotatef(45, 1.0f, 0.0f, 0.0f);


    // Fuselaje
    glPushMatrix();
    glScalef(1.0, 3.0, 1.0);
    glutSolidSphere(0.5, 20, 20);
    glPopMatrix();

    // aletas
    glPushMatrix();
    glTranslatef(0.0, 0.5, 0.0);
    glScalef(1.0, 1.0, 4.0);
    glutSolidCube(0.2);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0, -0.5, 0.0);
    glScalef(1.0, 1.0, 4.0);
    glutSolidCube(0.2);
    glPopMatrix();

    // Nose cone
    glPushMatrix();
    glTranslatef(0.0, 1.5, 0.0);
    glutSolidCone(0.3, 0.5, 20, 20);
    glPopMatrix();

    // Centro del Cohete
    centrocohete [0]=-5.0;
    centrocohete [1]=-translatefA;
    centrocohete [2]=-translatefB;

    // Creacion de la hitbox del cohete
    *cajadelcohete = hitbox(1.5f, 1.5f, 1.5f, centrocohete);

    glPopMatrix();

}
