#include "hitbox.h"

hitbox::hitbox(const float ancho, const float alto, const float prof, const float c[3])
{
        for (int i = 0; i < 3; i++) { // Dependiendo del centro del objeto, se exitende la hitbox a su alrededor
            centro[i] = c[i];
            extend[i] = 0;
        }
        extend[0] = ancho;
        extend[1] = alto;
        extend[2] = prof;
}

hitbox::~hitbox()
{
    //dtor
}
