#include "nave.h"
#include "cohetes.h"

nave::nave() // Constructor de la Nave
{
    float posnave_hor=-14;

    float posnavey=-14;

    float posnave_ver=0;

    float naverot=0;

    float xcoh1 = 7.0;
    float xcoh2 = 7.0;
    float xcoh3 = 7.0;
    float xcoh4 = 7.0;

}

nave::~nave()
{
    //dtor
}

void nave::set_posnave_hor(float n) {
    posnave_hor = n;
}
float nave::get_posnave_hor() {
    return posnave_hor;
}

void nave::set_posnavey(float n) {
    posnavey = n;
}
float nave::get_posnavey() {
    return posnavey;
}

void nave::set_posnave_ver(float n) {
    posnave_ver = n;
}
float nave::get_posnave_ver() {
    return posnave_ver;
}

void nave::set_naverot(float n) {
    naverot = n;
}
float nave::get_naverot() {
    return naverot;
}

void nave::set_naverot2(float n) {
    naverot2 = n;
}
float nave::get_naverot2() {
    return naverot2;
}

void nave::drawNave(hitbox* caja_cohe) {
    /*cohetes coh1; // Creacion de Cohete 1
    cohetes coh2; // Creacion de Cohete 2
    cohetes coh3; // Creacion de Cohete 3*/

    glPushMatrix();
    //glRotatef(naverot, 0.0f, 0.0f, 1.0f);
    glRotatef(90, 0.0f, 1.0f, 0.0f);//perfilamos con el escudo
    glRotatef(naverot2, 0.0f, 1.0f, 0.0f);
    glTranslatef(posnave_hor, posnave_ver, posnavey);
    glScalef(0.5f, 0.5f, 0.5f);
    glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

    // Base del Halc�n Milenario
    glPushMatrix();
    glColor3f(0.5f, 0.5f, 0.5f);
    glutSolidSphere(1.0f, 20, 20);
    glPopMatrix();

    // Cabina del Halc�n Milenario
    glPushMatrix();
    glColor3f(0.0f, 0.0f, 1.0f);
    glTranslatef(0.0f, 0.0f, 1.2f);
    glutSolidCone(0.4f, 0.8f, 20, 20);
    glPopMatrix();

    // Alas del Halc�n Milenario
    glPushMatrix();
    glColor3f(0.5f, 0.5f, 0.5f);
    glTranslatef(-0.9f, 0.0f, 0.0f);
    glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
    glScalef(2.0f, 0.2f, 0.2f);
    glutSolidCube(1.0f);
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.5f, 0.5f, 0.5f);
    glTranslatef(0.9f, 0.0f, 0.0f);
    glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
    glScalef(2.0f, 0.2f, 0.2f);
    glutSolidCube(1.0f);
    glPopMatrix();

    // Propulsores del Halc�n Milenario
    glPushMatrix();
    glColor3f(1.0f, 0.0f, 0.0f);
    glTranslatef(0.0f, 0.0f, -1.2f);
    glScalef(0.5f, 0.5f, 1.0f);
    glutSolidCone(0.4f, 0.8f, 20, 20);
    glPopMatrix();

    glPushMatrix();
    glColor3f(1.0f, 0.0f, 0.0f);
    glTranslatef(0.0f, 0.0f, -1.2f);
    glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
    glScalef(0.5f, 0.5f, 1.0f);
    glutSolidCone(0.4f, 0.8f, 20, 20);
    glPopMatrix();

    // Establecer el centro del cohete respecto a la posicion
    centrocohete[0]=get_posnave_hor();
    centrocohete[1]=get_posnavey();
    centrocohete[2]=get_posnave_ver();

    // Crear hitbox del cohete
    *caja_cohe = hitbox(0.5f, 0.5f, 0.5f, centrocohete);

    glutSwapBuffers();

    glPopMatrix();

}

void nave::updateNave() { // Movimiento de la Nave
    (posnave_hor + 0.08 < 6.0) ? posnave_hor += 0.08f : posnave_hor = -15.0f;
}
