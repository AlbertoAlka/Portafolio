#include "escudo.h"

escudo::escudo() // Constructor del Escudo
{

    anguloX = 0.0;
    anguloY = 0.0;
    deltaGiro = 7.0;

    posesc_hor=0;
    posescy=4.5;
    posesc_ver=0;

}

escudo::~escudo()
{
    //dtor
}

void escudo::set_posesc_hor(float n) {
    posesc_hor = n;
}
float escudo::get_posesc_hor() {
    return posesc_hor;
}

void escudo::set_posescy(float n) {
    posescy = n;
}
float escudo::get_posescy() {
    return posescy;
}

void escudo::set_posesc_ver(float n) {
    posesc_ver = n;
}
float escudo::get_posesc_ver() {
    return posesc_ver;
}

void escudo::draw(hitbox *caja) // Dibujado del Escudo
{
    glPushMatrix();
    glRotatef(anguloX, 0, 1, 0);
    glRotatef(anguloY, 1, 0, 0);
    glTranslatef(posesc_hor, posesc_ver, posescy);

    // Color verde para el escudo
    glColor3f(0.0, 1.0, 0.0);

    // Base del escudo
    glPushMatrix();
    glScalef(1.0, 0.2, 0.8);
    glutSolidCube(1.0);
    glPopMatrix();

    // Parte superior del escudo
    glPushMatrix();
    glTranslatef(0.0, 0.6, 0.0);
    glScalef(0.8, 0.5, 0.5);
    glutSolidCube(1.0);
    glPopMatrix();

    // Parte inferior del escudo
    glPushMatrix();
    glTranslatef(0.0, -0.6, 0.0);
    glScalef(0.8, 0.5, 0.5);
    glutSolidCube(1.0);
    glPopMatrix();

    // Parte izquierda del escudo
    glPushMatrix();
    glTranslatef(-0.6, 0.0, 0.0);
    glScalef(0.5, 0.8, 0.5);
    glutSolidCube(1.0);
    glPopMatrix();

    // Parte derecha del escudo
    glPushMatrix();
    glTranslatef(0.6, 0.0, 0.0);
    glScalef(0.5, 0.8, 0.5);
    glutSolidCube(1.0);
    glPopMatrix();

    // Capa de superh�roe
    // Color rojo para la capa
    glColor3f(1.0, 0.0, 0.0);
    glPushMatrix();
    glTranslatef(0.0, 0.0, -1.0);
    glScalef(3.0, 3.0, 0.3);  // Duplicar el tama�o de la capa
    glutSolidCube(1.0);
    glPopMatrix();

    //alas
    glPushMatrix();
    glTranslatef(0.0, 0.0, -0.3);
    glColor3f(0.0, 0.0, 1.0);

    // Ala izquierda
    glBegin(GL_TRIANGLES);
    glVertex3f(-2.1, 0.0, 0.0);
    glVertex3f(-1.5, 2.1, 0.0);
    glVertex3f(-0.9, 0.0, 0.0);
    glEnd();

    // Ala derecha
    glBegin(GL_TRIANGLES);
    glVertex3f(2.1, 0.0, 0.0);
    glVertex3f(1.5, 2.1, 0.0);
    glVertex3f(0.9, 0.0, 0.0);
    glEnd();
    glPopMatrix();

    // Centro del Escudo
    centro_escudo[0]=get_posesc_hor();
    centro_escudo[1]=get_posescy();
    centro_escudo[2]=get_posesc_ver();

    // Crea hitbox del escudo
    *caja = hitbox(2.5f, 2.5f, 2.5f, centro_escudo);

    glPopMatrix();

}

void escudo::update(int key) // Movimiento del Escudo por parte de jugador
{
    if (key == 2)
    {
        (anguloX + deltaGiro < 360.0) ? anguloX += deltaGiro : anguloX = 0.0f;
        (control_x + deltaGiro < 360.0) ? control_x += deltaGiro : control_x = 0.0f;
    }
    else if (key == 3)
    {
        (anguloX - deltaGiro < 360.0) ? anguloX -= deltaGiro : anguloX = 0.0f;
        (control_x - deltaGiro < 360.0) ? control_x -= deltaGiro : control_x = 0.0f;
    }
}

