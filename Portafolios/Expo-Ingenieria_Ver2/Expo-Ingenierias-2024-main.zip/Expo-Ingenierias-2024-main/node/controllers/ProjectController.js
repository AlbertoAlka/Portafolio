import db from "../database/db.js";
import {ProjectModel, PersonModel, JudgeProjectModel, AsessorProjectModel, StudentModel, 
    AdminModel, TeamModel, MaterialModel, MaterialProjectModel, CategoryModel, AreaModel, EditionModel, DisqualifiedModel, 
    CommentModel, CriteriaModel, CriteriaJudgeModel, TeamMemberModel, ProjectDisqualifiedModel} from "../models/Relations.js"
import { Sequelize } from 'sequelize';  // Import Sequelize
import { Op } from 'sequelize';  // Import operator from Sequelize
//** Métodos para el CRUD **/
export const GetFinalGradeByProjectId = async (req, res) => {
    try {
        // Buscar todas las calificaciones del proyecto por su ID
        const criteriaJudges = await CriteriaJudgeModel.findAll({
            where: { id_project: req.params.id }
        });

        if (criteriaJudges.length === 0) {
            return res.status(404).json({ message: 'No hay calificaciones para este proyecto.' });
        }

        // Sumar todas las calificaciones
        let totalGradeSum = 0;
        criteriaJudges.forEach(criteriaJudge => {
            totalGradeSum += criteriaJudge.grade;
        });

        // Calcular el número de conjuntos de 5 calificaciones
        const numberOfSets = criteriaJudges.length / 5;

        // Calcular el promedio de las calificaciones
        const finalGrade = (totalGradeSum / criteriaJudges.length).toFixed(2);

        res.json({ finalGrade });
    } catch (error) {
        console.error('Error al obtener la calificación final del proyecto:', error);
        res.status(500).json({ message: 'Hubo un error al obtener la calificación final del proyecto.' });
    }
}
export const UpdateFinalGradeByProjectId = async (req, res) => {
    try {
        // Buscar todas las calificaciones del proyecto por su ID
        const criteriaJudges = await CriteriaJudgeModel.findAll({
            where: { id_project: req.params.id }
        });

        if (criteriaJudges.length === 0) {
            return res.status(404).json({ message: 'No hay calificaciones para este proyecto.' });
        }

        // Sumar todas las calificaciones
        let totalGradeSum = 0;
        criteriaJudges.forEach(criteriaJudge => {
            totalGradeSum += criteriaJudge.grade;
        });

        // Calcular el promedio de las calificaciones
        const finalGrade = (totalGradeSum / criteriaJudges.length).toFixed(2);

        // Actualizar la columna finalGrade en la tabla projects
        await ProjectModel.update(
            { finalGrade: finalGrade },
            { where: { id: req.params.id } }
        );

        res.json({ message: 'Calificación final actualizada correctamente.', finalGrade });
    } catch (error) {
        console.error('Error al actualizar la calificación final del proyecto:', error);
        res.status(500).json({ message: 'Hubo un error al actualizar la calificación final del proyecto.' });
    }
}



// Helper function to transform project data into the desired format
const transformProjectData = async (project) => {
    const leader = await StudentModel.findByPk(project.id_lider);
    const teacher = await PersonModel.findByPk(project.id_responsable);
    const category = await CategoryModel.findByPk(project.id_category);
    const area = await AreaModel.findByPk(project.id_area);
    const edition = await EditionModel.findByPk(project.id_edition);

    // Retrieve the team for the project
    const team = await TeamModel.findOne({
        where: { id_project: project.id },
        include: [
            { 
                model: StudentModel,
                as: 'leader'
            },
            { 
                model: StudentModel,
                as: 'members',
                through: { attributes: [] } // exclude join table attributes
            }
        ]
    });

    // Extract member names from the team
    const memberNames = team.members.map(member => member.name);

    // Determine if project is reviewed
    const isReviewed = project.statusGeneral === "aprobado";

    // Check if the project is disqualified
    const disqualifiedEntry = await DisqualifiedModel.findOne({
        where: { id_project: project.id }
    });
    const isDisqualified = disqualifiedEntry !== null;

    // Retrieve all person IDs related to the project
    const assessorEntries = await AsessorProjectModel.findAll({
        where: { id_project: project.id },
        attributes: ['id_person']
    });
    const assessorIds = assessorEntries.map(entry => entry.id_person);

    // Retrieve the names of the persons
    const assessors = await PersonModel.findAll({
        where: { id: assessorIds },
        attributes: ['name']
    });
    const teacherNames = assessors.map(assessor => assessor.name);

    // Include the responsible teacher at the beginning of the teacher names array
    if (teacher) {
        teacherNames.unshift(teacher.name);
    }

    // Determine the appropriate image based on the category title
    let img;
    if (category.title === "Concepto") {
        img = "Concepto.jpg";
    } else if (category.title === "Prototipo") {
        img = "Prototipo.jpg";
    } else if (category.title === "Producto") {
        img = "Producto.jpg";
    } else {
        img = "Areas.png"; // Default image
    }

    return {
        id: project.id,
        title: project.title,
        review: isReviewed,
        img: img, // Placeholder, update as necessary
        poster: project.linkPoster,
        video: project.linkVideo,
        description: project.description,
        categories: [category.title, area.name], 
        id_category: project.id_category,
        id_area: project.id_area,
        leader: leader.name,
        members: memberNames,
        teachers: teacherNames, 
        edition: edition.id, 
        score: project.finalGrade, 
        isDisqualified: isDisqualified
    };
};

// Mostrar todos los registros
export const getAllProjectsChart = async (req, res) => {
    try {
        const projects = await ProjectModel.findAll();

        const transformedProjects = await Promise.all(
            projects.map(project => transformProjectData(project))
        );

        res.json(transformedProjects);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//mostrarProyectoAdmin
export const getProjectAdmin = async (req, res) => {
    try {
        const { id } = req.params;
        const project = await ProjectModel.findByPk(id);

        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        const transformedProject = await transformProjectData(project);
        res.json(transformedProject);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Fetch a single project by ID
export const getProjectChart = async (req, res) => {
    try {
        const { id } = req.params;
        const project = await ProjectModel.findByPk(id);

        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        const transformedProject = await transformProjectData(project);
        res.json(transformedProject);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Function to disqualify a project
export const disqualifyProject = async (req, res) => {
    const { id_admin, id_project, reason } = req.body;

    // Check if all required fields are provided
    if (!id_admin || !id_project || !reason) {
        return res.status(400).json({ message: "id_admin, id_project, and reason are required" });
    }

    try {
        // Check if the admin exists
        const admin = await AdminModel.findByPk(id_admin);
        if (!admin) {
            return res.status(404).json({ message: "Admin not found" });
        }
        
        // Check if the project exists
        const project = await ProjectModel.findByPk(id_project);
        if (!project) {
            return res.status(404).json({ message: "Project not found" });
        }

        // Create the disqualification entry
        await DisqualifiedModel.create({
            id_admin: id_admin,
            id_project: id_project,
            reason: reason
        });

        res.status(201).json({ message: "Project disqualified successfully" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get all judges assigned to a project
// export const getProjectJudges = async (req, res) => {
//     const { projectId } = req.query; // Assume the project ID is provided as a query string

//     try {
//         // Retrieve the project to ensure it exists
//         const project = await ProjectModel.findByPk(projectId);

//         if (!project) {
//             return res.status(404).json({ message: 'Project not found' });
//         }

//         // Retrieve all person IDs related to the project
//         const judgeEntries = await JudgeProjectModel.findAll({
//             where: { id_project: project.id },
//             attributes: ['id_person']
//         });

//         // Extract the person IDs from the assessorEntries
//         const judgesIds = judgeEntries.map(entry => entry.id_person);


//         res.json(judgesIds);
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// };

export const getProjectJudges = async (req, res) => {
    const { projectId } = req.query; // Assume the project ID is provided as a query string

    try {
        // Retrieve the project to ensure it exists
        const project = await ProjectModel.findByPk(projectId);

        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        // Retrieve all person IDs related to the project
        const judgeEntries = await JudgeProjectModel.findAll({
            where: { id_project: project.id },
            attributes: ['id_person']
        });

        // Extract the person IDs from the judgeEntries
        const judgesIds = judgeEntries.map(entry => entry.id_person);

        // Retrieve all the information of the judges
        const judges = await PersonModel.findAll({
            where: { id: judgesIds }
            // You can add attributes if you want to select specific fields from PersonsModel
        });

        // Format the judges data
        const formattedJudges = judges.map(judge => ({
            id: judge.id,
            name: judge.name,
            lastName: judge.lastName,
            profileImg: "user.png"
        }));

        res.json(formattedJudges);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};



// Remove a judge from a project
export const removeProjectJudge = async (req, res) => {
    const { judgeId, projectId } = req.params; // Assume the judge ID and project ID are provided as URL parameters

    try {
        // Check if there are any comments associated with the judge for the project
        const commentExists = await CommentModel.findOne({
            where: {
                id_person: judgeId,
                id_project: projectId
            }
        });

        if (commentExists) {
            return res.status(400).json({ message: 'Cannot remove project judge because comments exist for the judge in the project' });
        }

        // Find the judge-project relation to ensure it exists
        const judgeProject = await JudgeProjectModel.findOne({
            where: {
                id_person: judgeId,
                id_project: projectId
            }
        });

        if (!judgeProject) {
            return res.status(404).json({ message: 'Judge not assigned to the project' });
        }

        // Remove the judge from the project
        await judgeProject.destroy();

        res.json({ message: 'Judge removed from the project successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add a judge to a project
export const assignProjectJudge = async (req, res) => {
    const { judgeId, projectId } = req.body; // Assume the judge ID and project ID are provided in the request body

    try {
        // Check if the judge-project relation already exists
        const existingRelation = await JudgeProjectModel.findOne({
            where: {
                id_person: judgeId,
                id_project: projectId
            }
        });

        if (existingRelation) {
            return res.status(400).json({ message: 'Judge is already assigned to the project' });
        }

        // Create a new entry in the JudgeProjectModel
        await JudgeProjectModel.create({
            id_person: judgeId,
            id_project: projectId
        });

        res.json({ message: 'Judge added to the project successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


//** Métodos para el CRUD **/

//Mostrar todos los registros
export const getAllProjects = async (req, res) => {
    try {
        const projects = await ProjectModel.findAll();

        const transformedProjects = await Promise.all(
            projects.map(project => transformProjectData(project))
        );

        res.json(transformedProjects);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}


export const getAllProjectsByAreas = async (req, res) => {
    try {
        const projects = await AreaModel.findAll(
            
            {where: {isActive: 1} ,include:
            [
                {model:ProjectModel,
                    required: false, 
                    where: {statusGeneral: 'aprobado'},
                    include: [
                    { model: AreaModel },
                    { model: CategoryModel },
                    { model: PersonModel,
                        as: 'Lider'
                    },
                    {
                        model: PersonModel,
                        as: 'Asesores'
                    },
                    { model: StudentModel },
                    { model: TeamModel,
                        include: [
                            {
                                model: StudentModel,
                                as: 'members'
                            }
                        ]
                    }
                    
                ]}
            ]
        })
        res.json(projects)
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Mostrar un proyecto
export const getProject = async (req, res) => {
    console.log(req.params.id)
    try {
        const project = await ProjectModel.findByPk(req.params.id, {
            include: [
                { model: AreaModel },
                { model: CategoryModel },
                { model: PersonModel,
                    as: 'Lider',
                },
                { model: StudentModel},
                { model: TeamModel,
                    include: [
                        {
                            model: StudentModel,
                            as: 'members'
                        }
                    ]
                },
                { model: CriteriaJudgeModel},

            ]
        });

        

        // Verificar si se encontró el proyecto
        if (!project) {
            return res.status(404).json({ message: 'El proyecto no fue encontrado.' });
        }

        const comentariosGenerales = []

        const comentariosAgrupados = {};
        

        var gradeCriteria1 = 0, gradeCriteria2 = 0, gradeCriteria3 = 0, gradeCriteria4 = 0, gradeCriteria5 = 0;
        var contadorJuez = 0;

         

        for(const criteriaJudge of project.criteria_judges){

            const comentarioGeneral = await CommentModel.findOne({
                where: { id_project: req.params.id, id_person: criteriaJudge.id_person }
            });


            if (!comentariosAgrupados[criteriaJudge.id_person]) {
                comentariosAgrupados[criteriaJudge.id_person] = {
                    id_juez: (contadorJuez+1),
                    comentarioGeneral: comentarioGeneral ? comentarioGeneral.comment : null,
                };

            }
            const comentarioKey = `comentario${criteriaJudge.id_criteria}`;
            comentariosAgrupados[criteriaJudge.id_person][comentarioKey] = criteriaJudge.Comentario ? criteriaJudge.Comentario: null;

            switch(criteriaJudge.id_criteria){
                case 1:
                    gradeCriteria1 += criteriaJudge.grade;
                    contadorJuez++
                break;
                case 2:
                    gradeCriteria2 += criteriaJudge.grade;
                break;
                case 3:
                    gradeCriteria3 += criteriaJudge.grade;
                break;
                case 4:
                    gradeCriteria4 += criteriaJudge.grade;
                break;
                case 5:
                    gradeCriteria5 += criteriaJudge.grade;
                break;
            }
        }
        
        project.dataValues.comentariosAgrupados = comentariosAgrupados;


        const gradeCriteria1Rounded = (gradeCriteria1/contadorJuez).toFixed(2);
        const gradeCriteria2Rounded = (gradeCriteria2/contadorJuez).toFixed(2);
        const gradeCriteria3Rounded = (gradeCriteria3/contadorJuez).toFixed(2); 
        const gradeCriteria4Rounded = (gradeCriteria4/contadorJuez).toFixed(2); 
        const gradeCriteria5Rounded = (gradeCriteria5/contadorJuez).toFixed(2);

        project.dataValues.gradeCriteria1 = gradeCriteria1Rounded
        project.dataValues.gradeCriteria2 = gradeCriteria2Rounded
        project.dataValues.gradeCriteria3 = gradeCriteria3Rounded
        project.dataValues.gradeCriteria4 = gradeCriteria4Rounded
        project.dataValues.gradeCriteria5 = gradeCriteria5Rounded



        

        // Obtener todos los comentarios asociados al proyecto
        const comments = await CommentModel.findAll({
            where: { id_person: project.Lider.id, id_project: req.params.id, },
            order: [['createdAt', 'DESC']]
        });

        if(comments.length ==0){
            
            project.dataValues.comment = null;
        }

        const latestComment = comments.length > 0 ? comments[0] : null;
        project.dataValues.comment = latestComment;

        const criterias = await CriteriaModel.findAll();
        project.dataValues.criterias = criterias;

        // Responder con el proyecto que incluye los nombres de la categoría y el área
        res.json(project);
    } catch (error) {
        // Manejar cualquier error que ocurra durante la consulta
        console.error('Error al obtener el proyecto:', error);
        res.status(500).json({ message: 'Hubo un error al obtener el proyecto.' });
    }
}


//Actualizar un proyecto
export const updateProject = async (req, res) => {
    try {
        await ProjectModel.update(req.body, {
            where: { id: req.params.id}
        })
        res.json({
            "message":"¡Registro actualizado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Eliminar un registro
export const deleteProject = async (req, res) => {
    try {
        await ProjectModel.destroy({ 
            where: { id : req.params.id }
        })
        res.json({
            "message":"¡Registro eliminado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Registro 
//Registro del proyecto
async function registerProject (req, res){

    var id_profesorAsesor = 0;
    
    const { id_student, title, description, linkVideo, linkPoster, area, category, materials, members, teachers } = req.body;
    //console.log(id_student + " " + title + " " , description + " " + linkVideo + " " + linkPoster +  " " + area + " " + category + " " + materials);  
    console.log(materials)
    //var codigo = title.substring(0,5) + description.substring(0,5) + area + category;

    var contadorProfe = 0;

    const teacherIds = [];
    // Para cada profesor, crear un objeto Person y guardarlo en la base de datos
    for (const teacher of teachers) {

        const existingPerson = await PersonModel.findOne({ where: { email: teacher.email } });
            
            if (!existingPerson){
                //id_person(codigo + contadorProfe + "T"),
                const person = await PersonModel.create({
                    id: teacher.email,
                    name: teacher.name,
                    lastName: teacher.lastName,
                    email: teacher.email,
                    isJudge: 0,
                    ISACTIVE: 1
                });
                if (contadorProfe === 0){
                    id_profesorAsesor = person.id;
                }
                else{
                    teacherIds.push(person.id);
                }

            }
            else{
                if (contadorProfe === 0){
                    id_profesorAsesor = existingPerson.id;
                }
                else{
                    teacherIds.push(existingPerson.id);
                }
            }

        contadorProfe++;

    // Guardar la persona en la base de datos o realizar alguna acción necesaria
    }
    let nombreArea = await AreaModel.findOne({where: {id: area}});
    let nombreCategoria = await CategoryModel.findOne({where: {id: category}});
    let prefix = nombreArea["name"].substring(0,3) + nombreCategoria["title"].substring(0,3)

    const project = await ProjectModel.create({
        title,
        description,
        linkVideo,
        linkPoster,
        statusGeneral: "en revision",
        statusPoster: "en revision",
        statusVideo: "en revision",
        id_edition: 1,
        id_area: area,
        id_category: category,
        id_responsable: id_profesorAsesor,
        id_lider: id_student,
        prefix: prefix
    });

    const projectId = project.id
    console.log(projectId)

        // Añadir los profesores al proyecto
    console.log(teacherIds);
    if (teacherIds.length > 0) {
        await project.addAsesores(teacherIds);  // Asegúrate de que este método coincide con tu relación definida
        console.log('Profesores añadidos al proyecto')
    }
    console.log("ya pasó")
    // Crear un nuevo proyecto con los datos recibidos

    // Guardar el proyecto en la base de datos
    const team = await TeamModel.create({
        name: title,
        id_leader: id_student,
        id_project: projectId
    });
    console.log("paso del equipo")
    // Para cada miembro, crear un objeto Student y guardarlo en la base de datos
    var contadorStudent = 0
    for (const member of members) {
        const existingStudent = await StudentModel.findOne({ where: { enrollment: member.enrollment } });

        //id_student: (codigo + contadorStudent + "S")
        if (!existingStudent){
            const student = await StudentModel.create({
                id: member.enrollment,
                name: member.name,
                lastName: member.lastName,
                enrollment: member.enrollment,
                isActive: 1
            })
            await team.addMember(student);
        }
        else{
            await team.addMember(existingStudent);
        }
        
        contadorStudent++;


    // Guardar el estudiante en la base de datos o realizar alguna acción necesaria
    }



    for (const material of materials) {
        await MaterialProjectModel.create({
            id_project: projectId,
            id_material: material.id_material,
            amount: material.amount
        });
    }

      // Responder al cliente con un mensaje de éxito o cualquier otro dato necesario
    res.json({ message: 'Datos guardados exitosamente.' });
}

async function formProject() {
    const materiales = await MaterialModel.findAll();
    const categories = await CategoryModel.findAll({
        where: {isActive: 1}
    });
    const areas = await AreaModel.findAll(
        {where: {isActive: 1}}
    );
    const teachers = await PersonModel.findAll(
        {where: {ISACTIVE: 1}}
    );
    const students = await StudentModel.findAll(
        {where: {isActive: 1}}
    );
    return {
        students: students,
        teachers: teachers,
        categories: categories,
        areas: areas,
        materials: materiales
    };
}

export const handleRegister = async(req, res) => {
    if (req.method === 'GET') {
        try {
            const data = await formProject();
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    } else if (req.method === 'POST') {
        try {
            await registerProject(req, res);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    } else {
        // Manejar otros métodos HTTP si es necesario
        res.status(405).send('Método HTTP no permitido');
    }
}


export const getProjectsByResponsable = async (req, res) => {
    try {
        const projects = await ProjectModel.findAll({
            where: { id_responsable: req.params.id_responsable },
            include: [
              { model: AreaModel, as: 'area' },
              { model: CategoryModel, as: 'category' }
            ]
          });
  
      // Aplanar los datos
      const flattenedProjects = projects.map(project => ({
        id: project.id,
        title: project.title,
        description: project.description,
        linkVideo: project.linkVideo,
        linkPoster: project.linkPoster,
        statusGeneral: project.statusGeneral,
        statusPoster: project.statusPoster,
        statusVideo: project.statusVideo,
        area: project.area.name,
        category: project.category.title,
        person: project.person,
        student: project.student,
        team: project.team,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt
      }));
  
      res.json(flattenedProjects);
    } catch (error) {
      console.error('Error al obtener los proyectos:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };
  

//Actualizar un proyecto
async function getProjectById(id) {
    try {
        const project = await ProjectModel.findByPk(id);

        // Verificar si se encontró el proyecto
        if (!project) {
            throw new Error('El proyecto no fue encontrado.');
        }

        return project;
    } catch (error) {
        // Manejar cualquier error que ocurra durante la consulta
        console.error('Error al obtener el proyecto:', error);
        throw error;
    }
}

async function updateProjectById(req,res) {
    try {
        console.log(req.body)
        req.body.statusGeneral = "en revision";
        await ProjectModel.update(req.body, {
            where: { id: req.params.id}
        })
        res.json({
            "message":"¡Registro actualizado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}


export const handleEdition = async (req, res) => {
   
    console.log(req.method);

    if (req.method === 'GET') {
        try {
            const data = await getProjectById(req.params.id);
            res.json(data);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    } else if (req.method === 'PUT') {
        try {
            console.log(req.body);
            await updateProjectById(req, res);
        } catch (error) {
            res.status(500).json({ error: 'Hubo un error al procesar los datos.' });
        }
    } else {
        res.status(405).send('Método HTTP no permitido');
    }
};


//Eliminar un proyecto y obtener un resumen de los proyectos de un estudiante
async function getProjectByStudentID(id_student) {
    try {

        const disqualifiedProjectIds = await ProjectDisqualifiedModel.findAll({
            attributes: ['id_project'],
            raw: true
        });

        const disqualifiedIds = disqualifiedProjectIds.map(dp => dp.id_project);

        const projects = await ProjectModel.findAll({
            where: {
                id_lider: id_student,
                id: {
                    [Op.notIn]: disqualifiedIds
                }
            },
            include:[
                {model: CategoryModel},
                {model: AreaModel}
            ]

    
        })
        // Verificar si se encontró el proyecto
        if (!projects) {
            throw new Error('Los proyectos no fueron encontrados.');
        }




        return projects;
    } catch (error) {
        // Manejar cualquier error que ocurra durante la consulta
        console.error('Error al obtener el proyecto:', error);
        throw error;
    }
}

async function deleteProjectByID(id_project) {
    try {
        const projectDeleteCount = await ProjectModel.destroy({
            where: { id: id_project },
        });
        console.log(`Proyectos eliminados: ${projectDeleteCount}`);
        return { message: 'Proyecto y sus registros relacionados eliminados correctamente.' };
    } catch (error) {
        // Manejar cualquier error qu ocurra durante la consulta
        console.error('Error al eliminar el proyecto y sus registros relacionados:', error);
        throw error;
    }
}

export const handleResumen = async (req, res) => {

    if (req.method === 'GET') {
        try {
            const data = await getProjectByStudentID(req.params.id);
            res.json(data);
        } catch (error) {
            console.error('Error al obtener proyectos:', error);
            res.status(500).json({ message: error.message });
        }
    } else if (req.method === 'DELETE') {
        try {
            const message = await deleteProjectByID(req.params.id);
            console.log('Mensaje de eliminación:', message);
            res.json(message);
        } catch (error) {
            console.error('Error al eliminar el proyecto:', error);
            res.status(500).json({ error: 'Hubo un error al eliminar el proyecto.' });
        }
    } else {
        res.status(405).send('Método HTTP no permitido');
    }
};

//** Extra Methods **/

// Fetch project status data for the doughnut chart
export const getProjectStatusData = async (req, res) => {
  try {
    const reviewedCount = await ProjectModel.count({
      where: {
        statusGeneral: 'aprobado'
      }
    });

    const pendingCount = await ProjectModel.count({
      where: {
        statusGeneral: 'en revision'
      }
    });
    const rejectedCount = await ProjectModel.count({
        where: {
          statusGeneral: 'rechazado'
        }
      });

    res.json({
      labels: ['Aprobados', 'En revisión','Rechazados'],
      data: [reviewedCount, pendingCount,rejectedCount]
    });
  } catch (error) {
    console.error('Error fetching project status data:', error);
    res.status(500).json({ error: 'Internal server error while fetching project status data.' });
  }
};

// controllers/MaterialController.js
export const getMaterialChecklistItems = async (req, res) => {
    try {
        // Fetch all materials
        const materials = await MaterialModel.findAll();

        // Fetch the total amounts for each material
        const totalAmounts = await MaterialProjectModel.findAll({
            attributes: [
                'id_material',
                [Sequelize.fn('SUM', Sequelize.col('amount')), 'totalAmount']
            ],
            group: ['id_material']
        });

        // Convert the totals to a lookup object
        const totalAmountsLookup = totalAmounts.reduce((acc, item) => {
            acc[item.id_material] = item.dataValues.totalAmount;
            return acc;
        }, {});

        // Format materials into checklist items
        const checklistItems = materials.map(material => ({
            id: material.id,
            text: `${material.name} (${totalAmountsLookup[material.id] || 0})`, // Name with total amount in brackets
        }));

        res.json(checklistItems);
    } catch (error) {
        console.error("Error fetching checklist items:", error);
        res.status(500).json({ error: "Internal server error while fetching checklist items." });
    }
};


export const getProjectMaterialChecklistItems = async (req, res) => {
    try {
        const projectId = req.params.projectId;

        // Fetch all materials
        const materials = await MaterialModel.findAll();

        // Fetch the total amounts for each material for the specific project
        const totalAmounts = await MaterialProjectModel.findAll({
            attributes: [
                'id_material',
                [Sequelize.fn('SUM', Sequelize.col('amount')), 'totalAmount']
            ],
            where: {
                id_project: projectId
            },
            group: ['id_material']
        });

        // Convert the totals to a lookup object
        const totalAmountsLookup = totalAmounts.reduce((acc, item) => {
            acc[item.id_material] = item.dataValues.totalAmount;
            return acc;
        }, {});

        // Format materials into checklist items
        const checklistItems = materials.map(material => ({
            id: material.id,
            text: `${material.name} (${totalAmountsLookup[material.id] || 0})`, // Name with total amount in brackets
        }));

        res.json(checklistItems);
    } catch (error) {
        console.error("Error fetching checklist items:", error);
        res.status(500).json({ error: "Internal server error while fetching checklist items." });
    }
};


// Función para obtener todos los proyectos ordenados de manera ascendente por id
export const fetchAllProjects = async () => {
  try {
    const projects = await Project.findAll({
      order: [
        ['id', 'ASC'] // Orden ascendente por la columna 'id'
      ]
    });
    return projects;
  } catch (error) {
    console.error('Error al obtener los proyectos:', error);
    throw error;
  }
}

// Función para obtener un proyecto por su ID
export const fetchProjectById = async (projectId) => {
  try {
    const project = await Project.findByPk(projectId); // Utilizamos findByPk para buscar por primary key
    if (!project) {
      throw new Error(`Proyecto con id ${projectId} no encontrado`);
    }
    return project;
  } catch (error) {
    console.error(`Error al obtener el proyecto con id ${projectId}:`, error);
    throw error;
  }
}


//Mostrar y actualizar materiales adicionales
async function getMaterialsByProyectID(id) {
    try {
        const projects = await MaterialProjectModel.findAll({
            where: {
                id_project: id
            }  
    })
        // Verificar si se encontró el proyecto
        if (!projects) {
            throw new Error('El proyecto no fue encontrado.');
        }

        return projects;
    } catch (error) {
        // Manejar cualquier error que ocurra durante la consulta
        console.error('Error al obtener el proyecto:', error);
        throw error;
    }
}


async function updateMaterialsByProjectID(req, res) {
    try {
        const projectId = req.params.id;
        const materials = req.body;
        console.log(req.body)
        for (const material of materials) {
            await MaterialProjectModel.update(
                { amount: material.amount },
                {
                    where: {
                        id_project: projectId,
                        id_material: material.id_material
                    }
                }
            );
        }
        res.json({
            "message":"¡Registro actualizado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}


export const handleMaterials = async (req, res) => {

    if (req.method === 'GET') {
        try {
            const data = await getMaterialsByProyectID(req.params.id);
            res.json(data);
        } catch (error) {
            console.error('Error al obtener materiales:', error);
            res.status(500).json({ message: error.message });
        }
    } else if (req.method === 'PUT') {
        try {

            const message = await updateMaterialsByProjectID(req,res);

            res.json(message);

        } catch (error) {
            console.error('Error al actualizar materiales del proyecto:', error);
            res.status(500).json({ error: 'Hubo un error al actualizar materiales del proyecto.' });
        }
    } else {
        res.status(405).send('Método HTTP no permitido');
    }
};


export const getProjectCertificate = async (req, res) => {
    try {
        const projects = await ProjectModel.findAll({
            where: {
                id_lider: req.params.id_person
            },

                include: [
                    { model: AreaModel },
                    { model: CategoryModel },
                    { model: PersonModel,
                        as: 'Lider',
                    },
                    { model: StudentModel },
                    { model: TeamModel,
                        include: [
                            {
                                model: StudentModel,
                                as: 'members'
                            }
                        ]
                    }
                ]
        });

        // Verificar si se encontró el proyecto
        if (!projects || projects.length === 0) {
            return res.status(404).json({ message: 'El proyecto no fue encontrado.' });
        }

        return res.status(200).json(projects);
    } catch (error) {
        // Manejar cualquier error que ocurra durante la consulta
        console.error('Error al obtener el proyecto:', error);
        return res.status(500).json({ message: 'Error al obtener el proyecto.', error: error.message });
    }
};
