// BASE Import
import './App.css';
import './Page.css';
//import {Routes, Route} from 'react-router-dom'
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import React, { useState,useEffect} from "react";

// Main
import ProjResumeCont from './Pages/Teacher/TeacherProjectResumen/TeacherProjectResumen.js';
import Hometeacher from './Pages/Teacher/TeacherHome/TeacherHome.js';
import Main from './Pages/Main/MainPage/main.js';
import EdicionesPasadas from './Pages/Main/PastEdition/EdicionesPasadas.js';
import Catalogo from './Pages/Main/Catalogue/Actual.js';
import Login from './Pages/Main/Login/login.js';
import FormUser from './Pages/Main/UserRegister/UserRegister.js';
import FormStudent from './Pages/Main/StudentRegister/StudentRegister.js';
import UserRegisterCont from './Pages/Main/RegisterContent/RegisterContent.js'
import AnunciosTeacher from './Pages/Teacher/TeacherAdvertisements/TeacherAdvertisements.js';
import ConstanciaTeacher from './Pages/Teacher/TeacherCertificate/TeacherConstancia.js';
import Perfil from './Pages/Teacher/TeacherProfile/TeacherProfile.js';
import EditPerfilTeacher from './Pages/Teacher/TeacherProfile/TeacherEditProfile.js'
import TeacherAnoDet from './Pages/Teacher/TeacherAdvertisements/DetailedAnnoun.js'
import ProjectRegister from './Pages/Student/ProjectRegister/ProjResgister.js';
import ProjectResumen from './Pages/Student/ProjectResumen/ProjectResumenContent.js';
import AnunciosStudent from './Pages/Student/Announcement/Announ.js'
import StudentCertificate from './Pages/Student/StudentCertificate/Constancia.js'
import MaterialExtra from './Pages/Student/ExtraMaterials/materiales.js';
import StudentMap from './Pages/Student/StudentMap/StudentMap.js';
import ProjSelection from './Pages/Student/ProjectSelection/ProjSelection.js';
import ProjectEdition from './Pages/Student/ProjectEdition/ProjEdition.js';
import StudentAnnounDet from './Pages/Student/Announcement/DetailedAnnoun.js'
import StudentProfile from './Pages/Student/StudentProfile/StudentProfile.js';
import EditPerfilStudent from './Pages/Student/StudentProfile/StudentEditProfile.js'
//import { BrowserRouter as useLocation } from 'react-router-dom';

// Admin
import Dashboard from './Pages/Admin/Dashboard';
import Historical from './Pages/Admin/Historical';
import Users from './Pages/Admin/Users';
import Judges from './Pages/Admin/Judges';
import EditUserPage from './Pages/Admin/EditUserPage';
import Projects from './Pages/Admin/Projects';
import ProjectPage from './Pages/Admin/ProjectPage/ProjectPage.js';
import Categorias from './Pages/Admin/Categorias';
import Areas from './Pages/Admin/Areas';
import EditAreaPage from './Pages/Admin/EditAreas';
import EditCategoryPage from './Pages/Admin/EditCategory';
import EditAnnouncePage from './Pages/Admin/EditAnnounces';
import CreateAreaPage from './Pages/Admin/CreateArea';
import CreateCategoryPage from './Pages/Admin/CreateCategory';
import CreateAnnouncePage from './Pages/Admin/CreateAnnounce';
import Announces from './Pages/Admin/Announces';
import AdminRubrica from './Pages/Admin/AdminRubrica';
import PerfilAdmin from './Pages/Admin/AdminProfile.js';
import EditAdminProfile from './Pages/Admin/AdminEditProfile.js';
import ProjectRubric from './Pages/Admin/ProjectRubric.js';
import AdminMap from './Pages/Admin/AdminMap.js';

// Judge
import Juez from './Pages/Juez/Juez'; // Mis Proyectos
import ProjResumeContJudge from './Pages/Juez/ProjectResumenContent';
import Rubrica from './Pages/Juez/Rubrica';
import JudgeMap from './Pages/Juez/JudgeMap.js';

// Auth0
import Callback from './auth0/callback.js';
import ProtectedRoute from './auth0/protect.js';



function App() {
  // const location = useLocation(); // Get current location
  // const [pageTitle, setPageTitle] = useState('');

  // useEffect(() => {
  //   // Update the page title whenever the location changes
  //   setPageTitle(getTitle(location.pathname));
  // }, [location.pathname]);

  
  
  return (
    <>
      <div>
          <Routes>
              {/*Main Routes */}
              <Route path="/" element={<Main />} />
              <Route path="/Ediciones-pasadas" element={<EdicionesPasadas />} />
              <Route path="/Catalogo" element={<Catalogo />} />

              {/*Teacher Routes */}
              <Route path="/principal-profesor" element={<ProtectedRoute requiredRole="teacher"><Hometeacher /></ProtectedRoute>} />
              <Route path="/profesor/:id_project" element={<ProtectedRoute requiredRole="teacher"><ProjResumeCont /></ProtectedRoute>} />
              <Route path="/login" element={<Login />} />
              <Route path="/Registro-usuario" element={<ProtectedRoute requiredRole="teacher"><FormUser /></ProtectedRoute>} />
              <Route path="/Registro-inicio" element={<ProtectedRoute requiredRole="teacher"><UserRegisterCont /></ProtectedRoute>} />
              <Route path="/anuncios-profesor" element={<ProtectedRoute requiredRole="teacher"><AnunciosTeacher /></ProtectedRoute>} />
              <Route path="/constancia-profesor" element={<ProtectedRoute requiredRole="teacher"><ConstanciaTeacher/></ProtectedRoute>} />
              <Route path="/perfil-profesor" element={<ProtectedRoute requiredRole="teacher"><Perfil /></ProtectedRoute>} />
              <Route path="/announ-teacher/:id_announ" element={<ProtectedRoute requiredRole="teacher"><TeacherAnoDet /></ProtectedRoute>} />
              <Route path="/editar-perfil-profesor" element={<ProtectedRoute requiredRole="teacher"><EditPerfilTeacher /></ProtectedRoute>} />

              {/*Student Routes */}
              <Route path='/announ-estudiante/:id_announ' element={<ProtectedRoute requiredRole="student"><StudentAnnounDet /></ProtectedRoute>} />
              <Route path="/registro-proyecto" element={<ProtectedRoute requiredRole="student"><ProjectRegister /></ProtectedRoute>} />
              <Route path="/resumen-proyecto-estudiante/:id_project" element={<ProtectedRoute requiredRole="student"><ProjectResumen /></ProtectedRoute>} />
              <Route path="/anuncio-estudiante" element={<ProtectedRoute requiredRole="student"><AnunciosStudent /></ProtectedRoute>} />
              <Route path="/constancia-estudiante" element={<ProtectedRoute requiredRole="student"><StudentCertificate/></ProtectedRoute>} />
              <Route path="/extramaterial/:id_project" element={<ProtectedRoute requiredRole="student"><MaterialExtra ProjCheck={"True"}/></ProtectedRoute>} />
              <Route path="/mapa" element={<ProtectedRoute requiredRole="student"><StudentMap /></ProtectedRoute>} />
              <Route path="/principal-estudiante" element={<ProtectedRoute requiredRole="student"><ProjSelection/></ProtectedRoute>} />
              <Route path='/EditProject/:id_project' element={<ProtectedRoute requiredRole="student"><ProjectEdition /></ProtectedRoute>} />
              <Route path='/student-profile/' element={<ProtectedRoute requiredRole="student"><StudentProfile /></ProtectedRoute>} />
              <Route path='/editar-perfil-estudiante' element={<ProtectedRoute requiredRole="student"><EditPerfilStudent /></ProtectedRoute>} />
              <Route path="/Callback" element={<Callback />} />

              {/* Admin Routes */}
              <Route path="/Admin" element={<ProtectedRoute requiredRole="admin"><Dashboard /></ProtectedRoute>} />
              <Route path="/Admin/admin-profile" element={<ProtectedRoute requiredRole="admin"><PerfilAdmin /></ProtectedRoute>} />
              <Route path="/Admin/editar-admin-perfil" element={<ProtectedRoute requiredRole="admin"><EditAdminProfile /></ProtectedRoute>} />
              {/* historico */}
              <Route path="/Admin/historico" element={<ProtectedRoute requiredRole="admin"><Historical /></ProtectedRoute>} />
              {/* Manejo de usuarios */}
              <Route path="/Admin/usuarios" element={<ProtectedRoute requiredRole="admin"><Users /></ProtectedRoute>} />
              <Route path="/Admin/usuarios/jueces/:projectId" element={<ProtectedRoute requiredRole="admin"><Judges /></ProtectedRoute>} />
              <Route path="/Admin/usuarios/:userId" element={<ProtectedRoute requiredRole="admin"><EditUserPage /></ProtectedRoute>} />
              {/* Proyectos */}
              <Route path="/Admin/proyectos" element={<ProtectedRoute requiredRole="admin"><Projects /></ProtectedRoute>} />
              <Route path="/Admin/proyectos/:projectId" element={<ProtectedRoute requiredRole="admin"><ProjectPage /></ProtectedRoute>} />
              <Route path='/Admin/proyectos/calificar/:projectId' element={<ProtectedRoute requiredRole="admin"><ProjectRubric /></ProtectedRoute>}></Route>
              {/* manejo de áreas */}
              <Route path="/Admin/areas" element={<ProtectedRoute requiredRole="admin"><Areas/></ProtectedRoute>}/>
              <Route path='/Admin/areas/nuevo' element={<ProtectedRoute requiredRole="admin"><CreateAreaPage/></ProtectedRoute>}/>
              <Route path="/Admin/areas/:areaId" element={<ProtectedRoute requiredRole="admin"><EditAreaPage/></ProtectedRoute>}/>
              {/* Mapa */}
              <Route path="/Admin/mapa" element={<ProtectedRoute requiredRole="admin"><AdminMap/></ProtectedRoute>}/>
              {/* categorias */}
              <Route path='/Admin/categorias' element={<ProtectedRoute requiredRole="admin"><Categorias/></ProtectedRoute>}/>
              <Route path='/Admin/categorias/nuevo' element={<ProtectedRoute requiredRole="admin"><CreateCategoryPage/></ProtectedRoute>}/>
              <Route path='/Admin/Categorias/:categoriaId' element={<ProtectedRoute requiredRole="admin"><EditCategoryPage/></ProtectedRoute>}/>
              {/* Manejo de anuncios */}
              <Route path="/Admin/anuncios" element={<ProtectedRoute requiredRole="admin"><Announces/></ProtectedRoute>}/>
              <Route path='/Admin/anuncios/:anunciosId' element={<ProtectedRoute requiredRole="admin"><EditAnnouncePage/></ProtectedRoute>}/>
              <Route path='/Admin/anuncios/nuevo' element={<ProtectedRoute requiredRole="admin"><CreateAnnouncePage/></ProtectedRoute>}/>
              {/* Manejo de rubrica */}
              <Route path='/Admin/rubrica' element={<ProtectedRoute requiredRole="admin"><AdminRubrica /></ProtectedRoute>}/>

              {/* Judge Routes */}
              <Route path="/Juez" element={<ProtectedRoute requiredRole="teacher"><Juez /></ProtectedRoute>} />
              <Route path="/Juez/ProyectoJuez/:projectId" element={<ProtectedRoute requiredRole="teacher"><ProjResumeContJudge /></ProtectedRoute>} />
              <Route path="/Juez/Calificar/:projectId" element={<ProtectedRoute requiredRole="teacher"><Rubrica /></ProtectedRoute>} />
              <Route path="/Juez/Mapa" element={<ProtectedRoute requiredRole="teacher"><JudgeMap /></ProtectedRoute>} />
          </Routes>
      </div>
    </>
  );
}



export default App;
