
export const people = [{
    id: 'CP10',
    name: 'Tratamientos para pugs',
    area: 'Bio',
    categoria: 'prototipo',
    description: 'Un pug hermoso',
    status: 'aprobado'
},
{
    id: 1,
    name: 'Los pugs respiran ? ',
    area: 'Bio',
    categoria: 'idea',
    status: 'rechazado'
},
{
    id: 2,
    name: 'Son lindos los pugs',
    area: 'Bio',
    categoria: 'prototipo finalizado',
    status: 'rechazado'
},
{
    id: 3,
    name: 'Pug experimento de la naturaleza',
    area: 'Bio',
    categoria: 'idea',
    status: 'en revision'
},

    {
         id: 4,
        name: 'Más experimentos con pugs',
        area: 'Bio',
        categoria: 'prototipo',
        status: 'aprobado'
    },
    {
        id: 5,
        name: 'Tratamientos para pugs',
        area: 'Bio',
        categoria: 'prototipo',
        description: 'Un pug hermoso',
        status: 'en revision'
    },
    {
        id: 6,
        name: 'Los pugs respiran ? ',
        area: 'Bio',
        categoria: 'idea',
        status: 'aprobado'
    },
    {
        id: 7,
        name: 'Son lindos los pugs',
        area: 'Bio',
        categoria: 'idea',
        status: 'rechazado'
    }
];