export const projects = [{
    title: 'Robot automata para automatizar automatas',
    description: 'Robot Automata para Automatizar Autómatas es un proyecto innovador para desarrollar un sistema robótico que automatiza tareas complejas en la industria. Utiliza algoritmos avanzados de inteligencia artificial y aprendizaje automático para aumentar la eficiencia y precisión en la producción, optimizando recursos.',
    categoria: 'Prototipo finalizado',
    id_Proyecto: 'NPF10',
    status:'En revisión'
},
{
    title: 'Robot automata para automatizar automatas',
    description: 'Robot Automata para Automatizar Autómatas es un proyecto innovador para desarrollar un sistema robótico que automatiza tareas complejas en la industria. Utiliza algoritmos avanzados de inteligencia artificial y aprendizaje automático para aumentar la eficiencia y precisión en la producción, optimizando recursos.',
    categoria: 'Prototipo finalizado',
    id_Proyecto: 'NPF10',
    status:'En revisión'
},
{
    title: 'Robot automata para automatizar automatas',
    description: 'Robot Automata para Automatizar Autómatas es un proyecto innovador para desarrollar un sistema robótico que automatiza tareas complejas en la industria. Utiliza algoritmos avanzados de inteligencia artificial y aprendizaje automático para aumentar la eficiencia y precisión en la producción, optimizando recursos.',
    categoria: 'Concepto',
    id_Proyecto: 'NPF10',
    status:'En revisión'
}

];