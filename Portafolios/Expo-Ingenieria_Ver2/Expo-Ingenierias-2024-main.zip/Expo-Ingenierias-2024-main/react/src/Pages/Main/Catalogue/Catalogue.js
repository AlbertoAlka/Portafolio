import Menu from '../../Components/Menu/menu.js';
export default function Catalogo(){
    return(
        <>
        <Menu />
        </>
    );
}