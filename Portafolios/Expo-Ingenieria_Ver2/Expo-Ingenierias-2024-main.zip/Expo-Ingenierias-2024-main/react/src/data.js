import image1 from './img/CardConcept.png';
import image3 from './img/CardFinish.png';
import image4 from './img/CardProto.png';
export const people = [{
    id: 'CP10',
    name: 'Tratamientos para pugs',
    area: 'Bio',
    categoria: 'prototipo',
    description: 'Un pug hermoso',
    imageId: image1,
    status: 'aprobado'
},
{
    id: 1,
    name: 'Los pugs respiran ? ',
    area: 'Bio',
    categoria: 'idea',
    imageId: image3,
    status: 'rechazado'
},
{
    id: 2,
    name: 'Son lindos los pugs',
    area: 'Bio',
    categoria: 'prototipo finalizado',
    imageId: image3,
    status: 'rechazado'
},
{
    id: 3,
    name: 'Pug experimento de la naturaleza',
    area: 'Bio',
    categoria: 'idea',
    imageId: image4,
    status: 'en revision'
},

    {
         id: 4,
        name: 'Más experimentos con pugs',
        area: 'Bio',
        categoria: 'prototipo',
        imageId: image1,
        status: 'aprobado'
    },
    {
        id: 5,
        name: 'Tratamientos para pugs',
        area: 'Bio',
        categoria: 'prototipo',
        description: 'Un pug hermoso',
        imageId: image1,
        status: 'en revision'
    },
    {
        id: 6,
        name: 'Los pugs respiran ? ',
        area: 'Bio',
        categoria: 'idea',
        imageId: image1,
        status: 'aprobado'
    },
    {
        id: 7,
        name: 'Son lindos los pugs',
        area: 'Bio',
        categoria: 'idea',
        imageId: image1,
        status: 'rechazado'
    }
];